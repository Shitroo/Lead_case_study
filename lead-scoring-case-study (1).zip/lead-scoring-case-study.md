```python
# Suppressing Warnings
import warnings
warnings.filterwarnings('ignore')
```


```python
# Importing Pandas and NumPy
import pandas as pd, numpy as np

import matplotlib.pyplot as plt
import seaborn as sns
```


```python
# Importing lead dataset
lead_data = pd.read_csv("Leads.csv")
lead_data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Prospect ID</th>
      <th>Lead Number</th>
      <th>Lead Origin</th>
      <th>Lead Source</th>
      <th>Do Not Email</th>
      <th>Do Not Call</th>
      <th>Converted</th>
      <th>TotalVisits</th>
      <th>Total Time Spent on Website</th>
      <th>Page Views Per Visit</th>
      <th>...</th>
      <th>Get updates on DM Content</th>
      <th>Lead Profile</th>
      <th>City</th>
      <th>Asymmetrique Activity Index</th>
      <th>Asymmetrique Profile Index</th>
      <th>Asymmetrique Activity Score</th>
      <th>Asymmetrique Profile Score</th>
      <th>I agree to pay the amount through cheque</th>
      <th>A free copy of Mastering The Interview</th>
      <th>Last Notable Activity</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>7927b2df-8bba-4d29-b9a2-b6e0beafe620</td>
      <td>660737</td>
      <td>API</td>
      <td>Olark Chat</td>
      <td>No</td>
      <td>No</td>
      <td>0</td>
      <td>0.0</td>
      <td>0</td>
      <td>0.0</td>
      <td>...</td>
      <td>No</td>
      <td>Select</td>
      <td>Select</td>
      <td>02.Medium</td>
      <td>02.Medium</td>
      <td>15.0</td>
      <td>15.0</td>
      <td>No</td>
      <td>No</td>
      <td>Modified</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2a272436-5132-4136-86fa-dcc88c88f482</td>
      <td>660728</td>
      <td>API</td>
      <td>Organic Search</td>
      <td>No</td>
      <td>No</td>
      <td>0</td>
      <td>5.0</td>
      <td>674</td>
      <td>2.5</td>
      <td>...</td>
      <td>No</td>
      <td>Select</td>
      <td>Select</td>
      <td>02.Medium</td>
      <td>02.Medium</td>
      <td>15.0</td>
      <td>15.0</td>
      <td>No</td>
      <td>No</td>
      <td>Email Opened</td>
    </tr>
    <tr>
      <th>2</th>
      <td>8cc8c611-a219-4f35-ad23-fdfd2656bd8a</td>
      <td>660727</td>
      <td>Landing Page Submission</td>
      <td>Direct Traffic</td>
      <td>No</td>
      <td>No</td>
      <td>1</td>
      <td>2.0</td>
      <td>1532</td>
      <td>2.0</td>
      <td>...</td>
      <td>No</td>
      <td>Potential Lead</td>
      <td>Mumbai</td>
      <td>02.Medium</td>
      <td>01.High</td>
      <td>14.0</td>
      <td>20.0</td>
      <td>No</td>
      <td>Yes</td>
      <td>Email Opened</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0cc2df48-7cf4-4e39-9de9-19797f9b38cc</td>
      <td>660719</td>
      <td>Landing Page Submission</td>
      <td>Direct Traffic</td>
      <td>No</td>
      <td>No</td>
      <td>0</td>
      <td>1.0</td>
      <td>305</td>
      <td>1.0</td>
      <td>...</td>
      <td>No</td>
      <td>Select</td>
      <td>Mumbai</td>
      <td>02.Medium</td>
      <td>01.High</td>
      <td>13.0</td>
      <td>17.0</td>
      <td>No</td>
      <td>No</td>
      <td>Modified</td>
    </tr>
    <tr>
      <th>4</th>
      <td>3256f628-e534-4826-9d63-4a8b88782852</td>
      <td>660681</td>
      <td>Landing Page Submission</td>
      <td>Google</td>
      <td>No</td>
      <td>No</td>
      <td>1</td>
      <td>2.0</td>
      <td>1428</td>
      <td>1.0</td>
      <td>...</td>
      <td>No</td>
      <td>Select</td>
      <td>Mumbai</td>
      <td>02.Medium</td>
      <td>01.High</td>
      <td>15.0</td>
      <td>18.0</td>
      <td>No</td>
      <td>No</td>
      <td>Modified</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 37 columns</p>
</div>



## Data Inspection


```python
# checking the shape of the data 
lead_data.shape
```




    (9240, 37)



We have 9240 rows and 37 columns in our leads dataset.


```python
# checking non null count and datatype of the variables
lead_data.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 9240 entries, 0 to 9239
    Data columns (total 37 columns):
     #   Column                                         Non-Null Count  Dtype  
    ---  ------                                         --------------  -----  
     0   Prospect ID                                    9240 non-null   object 
     1   Lead Number                                    9240 non-null   int64  
     2   Lead Origin                                    9240 non-null   object 
     3   Lead Source                                    9204 non-null   object 
     4   Do Not Email                                   9240 non-null   object 
     5   Do Not Call                                    9240 non-null   object 
     6   Converted                                      9240 non-null   int64  
     7   TotalVisits                                    9103 non-null   float64
     8   Total Time Spent on Website                    9240 non-null   int64  
     9   Page Views Per Visit                           9103 non-null   float64
     10  Last Activity                                  9137 non-null   object 
     11  Country                                        6779 non-null   object 
     12  Specialization                                 7802 non-null   object 
     13  How did you hear about X Education             7033 non-null   object 
     14  What is your current occupation                6550 non-null   object 
     15  What matters most to you in choosing a course  6531 non-null   object 
     16  Search                                         9240 non-null   object 
     17  Magazine                                       9240 non-null   object 
     18  Newspaper Article                              9240 non-null   object 
     19  X Education Forums                             9240 non-null   object 
     20  Newspaper                                      9240 non-null   object 
     21  Digital Advertisement                          9240 non-null   object 
     22  Through Recommendations                        9240 non-null   object 
     23  Receive More Updates About Our Courses         9240 non-null   object 
     24  Tags                                           5887 non-null   object 
     25  Lead Quality                                   4473 non-null   object 
     26  Update me on Supply Chain Content              9240 non-null   object 
     27  Get updates on DM Content                      9240 non-null   object 
     28  Lead Profile                                   6531 non-null   object 
     29  City                                           7820 non-null   object 
     30  Asymmetrique Activity Index                    5022 non-null   object 
     31  Asymmetrique Profile Index                     5022 non-null   object 
     32  Asymmetrique Activity Score                    5022 non-null   float64
     33  Asymmetrique Profile Score                     5022 non-null   float64
     34  I agree to pay the amount through cheque       9240 non-null   object 
     35  A free copy of Mastering The Interview         9240 non-null   object 
     36  Last Notable Activity                          9240 non-null   object 
    dtypes: float64(4), int64(3), object(30)
    memory usage: 2.6+ MB
    

#### All the dataypes of the variables are in correct format.


```python
# Describing data
lead_data.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Lead Number</th>
      <th>Converted</th>
      <th>TotalVisits</th>
      <th>Total Time Spent on Website</th>
      <th>Page Views Per Visit</th>
      <th>Asymmetrique Activity Score</th>
      <th>Asymmetrique Profile Score</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>9240.000000</td>
      <td>9240.000000</td>
      <td>9103.000000</td>
      <td>9240.000000</td>
      <td>9103.000000</td>
      <td>5022.000000</td>
      <td>5022.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>617188.435606</td>
      <td>0.385390</td>
      <td>3.445238</td>
      <td>487.698268</td>
      <td>2.362820</td>
      <td>14.306252</td>
      <td>16.344883</td>
    </tr>
    <tr>
      <th>std</th>
      <td>23405.995698</td>
      <td>0.486714</td>
      <td>4.854853</td>
      <td>548.021466</td>
      <td>2.161418</td>
      <td>1.386694</td>
      <td>1.811395</td>
    </tr>
    <tr>
      <th>min</th>
      <td>579533.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>7.000000</td>
      <td>11.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>596484.500000</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>12.000000</td>
      <td>1.000000</td>
      <td>14.000000</td>
      <td>15.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>615479.000000</td>
      <td>0.000000</td>
      <td>3.000000</td>
      <td>248.000000</td>
      <td>2.000000</td>
      <td>14.000000</td>
      <td>16.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>637387.250000</td>
      <td>1.000000</td>
      <td>5.000000</td>
      <td>936.000000</td>
      <td>3.000000</td>
      <td>15.000000</td>
      <td>18.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>660737.000000</td>
      <td>1.000000</td>
      <td>251.000000</td>
      <td>2272.000000</td>
      <td>55.000000</td>
      <td>18.000000</td>
      <td>20.000000</td>
    </tr>
  </tbody>
</table>
</div>



From above description about counts, we can see that there are missing values present in our data. 

## Data Cleaning

### 1)Handling the 'Select' level that is present in many of the categorical variables.

We observe that there are 'Select' values in many columns.It may be because the customer did not select any option from the  list, hence it shows 'Select'.'Select' values are as good as NULL. So we can convert these values to null values.


```python
# Converting 'Select' values to NaN.
lead_data = lead_data.replace('Select', np.nan)
```


```python
# checking the columns for null values
lead_data.isnull().sum()
```




    Prospect ID                                         0
    Lead Number                                         0
    Lead Origin                                         0
    Lead Source                                        36
    Do Not Email                                        0
    Do Not Call                                         0
    Converted                                           0
    TotalVisits                                       137
    Total Time Spent on Website                         0
    Page Views Per Visit                              137
    Last Activity                                     103
    Country                                          2461
    Specialization                                   3380
    How did you hear about X Education               7250
    What is your current occupation                  2690
    What matters most to you in choosing a course    2709
    Search                                              0
    Magazine                                            0
    Newspaper Article                                   0
    X Education Forums                                  0
    Newspaper                                           0
    Digital Advertisement                               0
    Through Recommendations                             0
    Receive More Updates About Our Courses              0
    Tags                                             3353
    Lead Quality                                     4767
    Update me on Supply Chain Content                   0
    Get updates on DM Content                           0
    Lead Profile                                     6855
    City                                             3669
    Asymmetrique Activity Index                      4218
    Asymmetrique Profile Index                       4218
    Asymmetrique Activity Score                      4218
    Asymmetrique Profile Score                       4218
    I agree to pay the amount through cheque            0
    A free copy of Mastering The Interview              0
    Last Notable Activity                               0
    dtype: int64




```python
# Finding the null percentages across columns
round(lead_data.isnull().sum()/len(lead_data.index),2)*100
```




    Prospect ID                                       0.0
    Lead Number                                       0.0
    Lead Origin                                       0.0
    Lead Source                                       0.0
    Do Not Email                                      0.0
    Do Not Call                                       0.0
    Converted                                         0.0
    TotalVisits                                       1.0
    Total Time Spent on Website                       0.0
    Page Views Per Visit                              1.0
    Last Activity                                     1.0
    Country                                          27.0
    Specialization                                   37.0
    How did you hear about X Education               78.0
    What is your current occupation                  29.0
    What matters most to you in choosing a course    29.0
    Search                                            0.0
    Magazine                                          0.0
    Newspaper Article                                 0.0
    X Education Forums                                0.0
    Newspaper                                         0.0
    Digital Advertisement                             0.0
    Through Recommendations                           0.0
    Receive More Updates About Our Courses            0.0
    Tags                                             36.0
    Lead Quality                                     52.0
    Update me on Supply Chain Content                 0.0
    Get updates on DM Content                         0.0
    Lead Profile                                     74.0
    City                                             40.0
    Asymmetrique Activity Index                      46.0
    Asymmetrique Profile Index                       46.0
    Asymmetrique Activity Score                      46.0
    Asymmetrique Profile Score                       46.0
    I agree to pay the amount through cheque          0.0
    A free copy of Mastering The Interview            0.0
    Last Notable Activity                             0.0
    dtype: float64



We see that for some columns we have high percentage of missing values. We can drop the columns with missing values greater than 40% .


```python
# dropping the columns with missing values greater than or equal to 40% .
lead_data=lead_data.drop(columns=['How did you hear about X Education','Lead Quality','Lead Profile',
                                  'Asymmetrique Activity Index','Asymmetrique Profile Index','Asymmetrique Activity Score',
                                 'Asymmetrique Profile Score'])
```


```python
# Finding the null percentages across columns after removing the above columns
round(lead_data.isnull().sum()/len(lead_data.index),2)*100
```




    Prospect ID                                       0.0
    Lead Number                                       0.0
    Lead Origin                                       0.0
    Lead Source                                       0.0
    Do Not Email                                      0.0
    Do Not Call                                       0.0
    Converted                                         0.0
    TotalVisits                                       1.0
    Total Time Spent on Website                       0.0
    Page Views Per Visit                              1.0
    Last Activity                                     1.0
    Country                                          27.0
    Specialization                                   37.0
    What is your current occupation                  29.0
    What matters most to you in choosing a course    29.0
    Search                                            0.0
    Magazine                                          0.0
    Newspaper Article                                 0.0
    X Education Forums                                0.0
    Newspaper                                         0.0
    Digital Advertisement                             0.0
    Through Recommendations                           0.0
    Receive More Updates About Our Courses            0.0
    Tags                                             36.0
    Update me on Supply Chain Content                 0.0
    Get updates on DM Content                         0.0
    City                                             40.0
    I agree to pay the amount through cheque          0.0
    A free copy of Mastering The Interview            0.0
    Last Notable Activity                             0.0
    dtype: float64



#### 1)  Column: 'Specialization'

This column has 37% missing values


```python
plt.figure(figsize=(17,5))
sns.countplot(lead_data['Specialization'])
plt.xticks(rotation=90)
```




    (array([ 0,  1,  2,  3,  4,  5,  6,  7,  8,  9, 10, 11, 12, 13, 14, 15, 16,
            17]),
     [Text(0, 0, 'Business Administration'),
      Text(1, 0, 'Media and Advertising'),
      Text(2, 0, 'Supply Chain Management'),
      Text(3, 0, 'IT Projects Management'),
      Text(4, 0, 'Finance Management'),
      Text(5, 0, 'Travel and Tourism'),
      Text(6, 0, 'Human Resource Management'),
      Text(7, 0, 'Marketing Management'),
      Text(8, 0, 'Banking, Investment And Insurance'),
      Text(9, 0, 'International Business'),
      Text(10, 0, 'E-COMMERCE'),
      Text(11, 0, 'Operations Management'),
      Text(12, 0, 'Retail Management'),
      Text(13, 0, 'Services Excellence'),
      Text(14, 0, 'Hospitality Management'),
      Text(15, 0, 'Rural and Agribusiness'),
      Text(16, 0, 'Healthcare Management'),
      Text(17, 0, 'E-Business')])




    
![png](output_17_1.png)
    


There is 37% missing values present in the Specialization column .It may be possible that the lead may leave this column blank if he may be a student or not having any specialization or his specialization is not there in the options given. So we can create a another category 'Others' for this.


```python
# Creating a separate category called 'Others' for this 
lead_data['Specialization'] = lead_data['Specialization'].replace(np.nan, 'Others')
```

#### 2) Tags column

'Tags' column has 36% missing values


```python
# Visualizing Tags column
plt.figure(figsize=(10,7))
sns.countplot(lead_data['Tags'])
plt.xticks(rotation=90)
```




    (array([ 0,  1,  2,  3,  4,  5,  6,  7,  8,  9, 10, 11, 12, 13, 14, 15, 16,
            17, 18, 19, 20, 21, 22, 23, 24, 25]),
     [Text(0, 0, 'Interested in other courses'),
      Text(1, 0, 'Ringing'),
      Text(2, 0, 'Will revert after reading the email'),
      Text(3, 0, 'Lost to EINS'),
      Text(4, 0, 'In confusion whether part time or DLP'),
      Text(5, 0, 'Busy'),
      Text(6, 0, 'switched off'),
      Text(7, 0, 'in touch with EINS'),
      Text(8, 0, 'Already a student'),
      Text(9, 0, 'Diploma holder (Not Eligible)'),
      Text(10, 0, 'Graduation in progress'),
      Text(11, 0, 'Closed by Horizzon'),
      Text(12, 0, 'number not provided'),
      Text(13, 0, 'opp hangup'),
      Text(14, 0, 'Not doing further education'),
      Text(15, 0, 'invalid number'),
      Text(16, 0, 'wrong number given'),
      Text(17, 0, 'Interested  in full time MBA'),
      Text(18, 0, 'Still Thinking'),
      Text(19, 0, 'Lost to Others'),
      Text(20, 0, 'Shall take in the next coming month'),
      Text(21, 0, 'Lateral student'),
      Text(22, 0, 'Interested in Next batch'),
      Text(23, 0, 'Recognition issue (DEC approval)'),
      Text(24, 0, 'Want to take admission but has financial problems'),
      Text(25, 0, 'University not recognized')])




    
![png](output_21_1.png)
    


Since most values are 'Will revert after reading the email' , we can impute missing values in this column with this value. 


```python
# Imputing the missing data in the tags column with 'Will revert after reading the email'
lead_data['Tags']=lead_data['Tags'].replace(np.nan,'Will revert after reading the email')
```

#### 3)  Column: 'What matters most to you in choosing a course'

this column has 29% missing values


```python
# Visualizing this column
sns.countplot(lead_data['What matters most to you in choosing a course'])
plt.xticks(rotation=45)
```




    (array([0, 1, 2]),
     [Text(0, 0, 'Better Career Prospects'),
      Text(1, 0, 'Flexibility & Convenience'),
      Text(2, 0, 'Other')])




    
![png](output_25_1.png)
    



```python
# Finding the percentage of the different categories of this column:
round(lead_data['What matters most to you in choosing a course'].value_counts(normalize=True),2)*100
```




    Better Career Prospects      100.0
    Flexibility & Convenience      0.0
    Other                          0.0
    Name: What matters most to you in choosing a course, dtype: float64



We can see that this is highly skewed column so we can remove this column.


```python
# Dropping this column 
lead_data=lead_data.drop('What matters most to you in choosing a course',axis=1)
```

#### 4)  Column: 'What is your current occupation'

this column has 29% missing values


```python
sns.countplot(lead_data['What is your current occupation'])
plt.xticks(rotation=45)
```




    (array([0, 1, 2, 3, 4, 5]),
     [Text(0, 0, 'Unemployed'),
      Text(1, 0, 'Student'),
      Text(2, 0, 'Working Professional'),
      Text(3, 0, 'Businessman'),
      Text(4, 0, 'Other'),
      Text(5, 0, 'Housewife')])




    
![png](output_30_1.png)
    



```python
# Finding the percentage of the different categories of this column:
round(lead_data['What is your current occupation'].value_counts(normalize=True),2)*100
```




    Unemployed              85.0
    Working Professional    11.0
    Student                  3.0
    Other                    0.0
    Housewife                0.0
    Businessman              0.0
    Name: What is your current occupation, dtype: float64



Since the  most values are 'Unemployed' , we can impute missing values in this column with this value. 


```python
# Imputing the missing data in the 'What is your current occupation' column with 'Unemployed'
lead_data['What is your current occupation']=lead_data['What is your current occupation'].replace(np.nan,'Unemployed')
```

#### 5)  Column: 'Country'

This column has 27% missing values


```python
plt.figure(figsize=(17,5))
sns.countplot(lead_data['Country'])
plt.xticks(rotation=90)
```




    (array([ 0,  1,  2,  3,  4,  5,  6,  7,  8,  9, 10, 11, 12, 13, 14, 15, 16,
            17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33,
            34, 35, 36, 37]),
     [Text(0, 0, 'India'),
      Text(1, 0, 'Russia'),
      Text(2, 0, 'Kuwait'),
      Text(3, 0, 'Oman'),
      Text(4, 0, 'United Arab Emirates'),
      Text(5, 0, 'United States'),
      Text(6, 0, 'Australia'),
      Text(7, 0, 'United Kingdom'),
      Text(8, 0, 'Bahrain'),
      Text(9, 0, 'Ghana'),
      Text(10, 0, 'Singapore'),
      Text(11, 0, 'Qatar'),
      Text(12, 0, 'Saudi Arabia'),
      Text(13, 0, 'Belgium'),
      Text(14, 0, 'France'),
      Text(15, 0, 'Sri Lanka'),
      Text(16, 0, 'China'),
      Text(17, 0, 'Canada'),
      Text(18, 0, 'Netherlands'),
      Text(19, 0, 'Sweden'),
      Text(20, 0, 'Nigeria'),
      Text(21, 0, 'Hong Kong'),
      Text(22, 0, 'Germany'),
      Text(23, 0, 'Asia/Pacific Region'),
      Text(24, 0, 'Uganda'),
      Text(25, 0, 'Kenya'),
      Text(26, 0, 'Italy'),
      Text(27, 0, 'South Africa'),
      Text(28, 0, 'Tanzania'),
      Text(29, 0, 'unknown'),
      Text(30, 0, 'Malaysia'),
      Text(31, 0, 'Liberia'),
      Text(32, 0, 'Switzerland'),
      Text(33, 0, 'Denmark'),
      Text(34, 0, 'Philippines'),
      Text(35, 0, 'Bangladesh'),
      Text(36, 0, 'Vietnam'),
      Text(37, 0, 'Indonesia')])




    
![png](output_35_1.png)
    


We can see that this is highly skewed column but it is an important information w.r.t. to the lead. Since most values are 'India' , we can impute missing values in this column with this value.


```python
# Imputing the missing data in the 'Country' column with 'India'
lead_data['Country']=lead_data['Country'].replace(np.nan,'India')
```

#### 6)  Column: 'City'

This column has 40% missing values


```python
plt.figure(figsize=(10,5))
sns.countplot(lead_data['City'])
plt.xticks(rotation=90)
```




    (array([0, 1, 2, 3, 4, 5]),
     [Text(0, 0, 'Mumbai'),
      Text(1, 0, 'Thane & Outskirts'),
      Text(2, 0, 'Other Metro Cities'),
      Text(3, 0, 'Other Cities'),
      Text(4, 0, 'Other Cities of Maharashtra'),
      Text(5, 0, 'Tier II Cities')])




    
![png](output_39_1.png)
    



```python
# Finding the percentage of the different categories of this column:
round(lead_data['City'].value_counts(normalize=True),2)*100
```




    Mumbai                         58.0
    Thane & Outskirts              13.0
    Other Cities                   12.0
    Other Cities of Maharashtra     8.0
    Other Metro Cities              7.0
    Tier II Cities                  1.0
    Name: City, dtype: float64



Since most values are 'Mumbai' , we can impute missing values in this column with this value. 


```python
# Imputing the missing data in the 'City' column with 'Mumbai'
lead_data['City']=lead_data['City'].replace(np.nan,'Mumbai')
```


```python
# Finding the null percentages across columns after removing the above columns
round(lead_data.isnull().sum()/len(lead_data.index),2)*100
```




    Prospect ID                                 0.0
    Lead Number                                 0.0
    Lead Origin                                 0.0
    Lead Source                                 0.0
    Do Not Email                                0.0
    Do Not Call                                 0.0
    Converted                                   0.0
    TotalVisits                                 1.0
    Total Time Spent on Website                 0.0
    Page Views Per Visit                        1.0
    Last Activity                               1.0
    Country                                     0.0
    Specialization                              0.0
    What is your current occupation             0.0
    Search                                      0.0
    Magazine                                    0.0
    Newspaper Article                           0.0
    X Education Forums                          0.0
    Newspaper                                   0.0
    Digital Advertisement                       0.0
    Through Recommendations                     0.0
    Receive More Updates About Our Courses      0.0
    Tags                                        0.0
    Update me on Supply Chain Content           0.0
    Get updates on DM Content                   0.0
    City                                        0.0
    I agree to pay the amount through cheque    0.0
    A free copy of Mastering The Interview      0.0
    Last Notable Activity                       0.0
    dtype: float64



#### Rest missing values are under 2% so we can drop these rows.



```python
# Dropping the rows with null values
lead_data.dropna(inplace = True)
```


```python
# Finding the null percentages across columns after removing the above columns
round(lead_data.isnull().sum()/len(lead_data.index),2)*100
```




    Prospect ID                                 0.0
    Lead Number                                 0.0
    Lead Origin                                 0.0
    Lead Source                                 0.0
    Do Not Email                                0.0
    Do Not Call                                 0.0
    Converted                                   0.0
    TotalVisits                                 0.0
    Total Time Spent on Website                 0.0
    Page Views Per Visit                        0.0
    Last Activity                               0.0
    Country                                     0.0
    Specialization                              0.0
    What is your current occupation             0.0
    Search                                      0.0
    Magazine                                    0.0
    Newspaper Article                           0.0
    X Education Forums                          0.0
    Newspaper                                   0.0
    Digital Advertisement                       0.0
    Through Recommendations                     0.0
    Receive More Updates About Our Courses      0.0
    Tags                                        0.0
    Update me on Supply Chain Content           0.0
    Get updates on DM Content                   0.0
    City                                        0.0
    I agree to pay the amount through cheque    0.0
    A free copy of Mastering The Interview      0.0
    Last Notable Activity                       0.0
    dtype: float64



Now we don't have any missing value in the dataset. 
### We can find the percentage of rows retained.


```python
# Percentage of rows retained 
(len(lead_data.index)/9240)*100
```




    98.2034632034632



#### We have retained 98% of the rows after cleaning the data . 

# Exploratory Data Anaysis

### Checking for duplicates:


```python
lead_data[lead_data.duplicated()]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Prospect ID</th>
      <th>Lead Number</th>
      <th>Lead Origin</th>
      <th>Lead Source</th>
      <th>Do Not Email</th>
      <th>Do Not Call</th>
      <th>Converted</th>
      <th>TotalVisits</th>
      <th>Total Time Spent on Website</th>
      <th>Page Views Per Visit</th>
      <th>...</th>
      <th>Digital Advertisement</th>
      <th>Through Recommendations</th>
      <th>Receive More Updates About Our Courses</th>
      <th>Tags</th>
      <th>Update me on Supply Chain Content</th>
      <th>Get updates on DM Content</th>
      <th>City</th>
      <th>I agree to pay the amount through cheque</th>
      <th>A free copy of Mastering The Interview</th>
      <th>Last Notable Activity</th>
    </tr>
  </thead>
  <tbody>
  </tbody>
</table>
<p>0 rows × 29 columns</p>
</div>



We see there are no duplicate records in our lead dataset.

## Univariate Analysis and Bivariate Analysis

### 1) Converted 
#### Converted is the target variable, Indicates whether a lead has been successfully converted (1) or not (0)


```python
Converted = (sum(lead_data['Converted'])/len(lead_data['Converted'].index))*100
Converted
```




    37.85541106458012



The lead conversion rate is 38%.

### 2) Lead Origin


```python
plt.figure(figsize=(10,5))
sns.countplot(x = "Lead Origin", hue = "Converted", data = lead_data,palette='Set1')
plt.xticks(rotation = 45)
```




    (array([0, 1, 2, 3]),
     [Text(0, 0, 'API'),
      Text(1, 0, 'Landing Page Submission'),
      Text(2, 0, 'Lead Add Form'),
      Text(3, 0, 'Lead Import')])




    
![png](output_58_1.png)
    


### Inference :
1. API and Landing Page Submission have 30-35% conversion rate but count of lead originated from them are considerable.
2. Lead Add Form has more than 90% conversion rate but count of lead are not very high.
3. Lead Import are very less in count.

**To improve overall lead conversion rate, we need to focus more on improving lead converion of API and Landing Page Submission origin and generate more leads from Lead Add Form.**

### 3) Lead Source


```python
plt.figure(figsize=(13,5))
sns.countplot(x = "Lead Source", hue = "Converted", data = lead_data, palette='Set1')
plt.xticks(rotation = 90)
```




    (array([ 0,  1,  2,  3,  4,  5,  6,  7,  8,  9, 10, 11, 12, 13, 14, 15, 16,
            17, 18, 19, 20]),
     [Text(0, 0, 'Olark Chat'),
      Text(1, 0, 'Organic Search'),
      Text(2, 0, 'Direct Traffic'),
      Text(3, 0, 'Google'),
      Text(4, 0, 'Referral Sites'),
      Text(5, 0, 'Reference'),
      Text(6, 0, 'google'),
      Text(7, 0, 'Welingak Website'),
      Text(8, 0, 'Facebook'),
      Text(9, 0, 'blog'),
      Text(10, 0, 'Pay per Click Ads'),
      Text(11, 0, 'bing'),
      Text(12, 0, 'Social Media'),
      Text(13, 0, 'WeLearn'),
      Text(14, 0, 'Click2call'),
      Text(15, 0, 'Live Chat'),
      Text(16, 0, 'welearnblog_Home'),
      Text(17, 0, 'youtubechannel'),
      Text(18, 0, 'testone'),
      Text(19, 0, 'Press_Release'),
      Text(20, 0, 'NC_EDM')])




    
![png](output_61_1.png)
    



```python
# Need to replace 'google' with 'Google'
lead_data['Lead Source'] = lead_data['Lead Source'].replace(['google'], 'Google')
```


```python
# Creating a new category 'Others' for some of the Lead Sources which do not have much values.
lead_data['Lead Source'] = lead_data['Lead Source'].replace(['Click2call', 'Live Chat', 'NC_EDM', 'Pay per Click Ads', 'Press_Release',
  'Social Media', 'WeLearn', 'bing', 'blog', 'testone', 'welearnblog_Home', 'youtubechannel'], 'Others')

```


```python
# Visualizing again
plt.figure(figsize=(10,5))
sns.countplot(x = "Lead Source", hue = "Converted", data = lead_data,palette='Set1')
plt.xticks(rotation = 90)
```




    (array([0, 1, 2, 3, 4, 5, 6, 7, 8]),
     [Text(0, 0, 'Olark Chat'),
      Text(1, 0, 'Organic Search'),
      Text(2, 0, 'Direct Traffic'),
      Text(3, 0, 'Google'),
      Text(4, 0, 'Referral Sites'),
      Text(5, 0, 'Reference'),
      Text(6, 0, 'Welingak Website'),
      Text(7, 0, 'Facebook'),
      Text(8, 0, 'Others')])




    
![png](output_64_1.png)
    


### Inference
1. Google and Direct traffic generates maximum number of leads.
2. Conversion Rate of reference leads and leads through welingak website is high.

**To improve overall lead conversion rate, focus should be on improving lead converion of olark chat, organic search, direct traffic, and google leads and generate more leads from reference and welingak website.**

### 4) Do not Email 


```python
sns.countplot(x = "Do Not Email", hue = "Converted", data = lead_data,palette='Set1')
plt.xticks(rotation = 90)
```




    (array([0, 1]), [Text(0, 0, 'No'), Text(1, 0, 'Yes')])




    
![png](output_67_1.png)
    


### Inference
Most entries are 'No'. No Inference can be drawn with this parameter.

### 5) Do not call


```python
sns.countplot(x = "Do Not Call", hue = "Converted", data = lead_data,palette='Set1')
plt.xticks(rotation = 90)
```




    (array([0, 1]), [Text(0, 0, 'No'), Text(1, 0, 'Yes')])




    
![png](output_70_1.png)
    


### Inference
Most entries are 'No'. No Inference can be drawn with this parameter.

### 6) TotalVisits


```python
lead_data['TotalVisits'].describe(percentiles=[0.05,.25, .5, .75, .90, .95, .99])
```




    count    9074.000000
    mean        3.456028
    std         4.858802
    min         0.000000
    5%          0.000000
    25%         1.000000
    50%         3.000000
    75%         5.000000
    90%         7.000000
    95%        10.000000
    99%        17.000000
    max       251.000000
    Name: TotalVisits, dtype: float64




```python
sns.boxplot(lead_data['TotalVisits'],orient='vert',palette='Set1')
```




    <AxesSubplot:xlabel='TotalVisits'>




    
![png](output_74_1.png)
    


**As we can see there are a number of outliers in the data. We will cap the outliers to 95% value for analysis.**


```python
percentiles = lead_data['TotalVisits'].quantile([0.05,0.95]).values
lead_data['TotalVisits'][lead_data['TotalVisits'] <= percentiles[0]] = percentiles[0]
lead_data['TotalVisits'][lead_data['TotalVisits'] >= percentiles[1]] = percentiles[1]
```


```python
# Visualizing again
sns.boxplot(lead_data['TotalVisits'],orient='vert',palette='Set1')
```




    <AxesSubplot:xlabel='TotalVisits'>




    
![png](output_77_1.png)
    



```python
sns.boxplot(y = 'TotalVisits', x = 'Converted', data = lead_data,palette='Set1')
```




    <AxesSubplot:xlabel='Converted', ylabel='TotalVisits'>




    
![png](output_78_1.png)
    


### Inference
* Median for converted and not converted leads are the same.

Nothing can be concluded on the basis of Total Visits.

### 7) Total Time Spent on Website


```python
lead_data['Total Time Spent on Website'].describe()
```




    count    9074.000000
    mean      482.887481
    std       545.256560
    min         0.000000
    25%        11.000000
    50%       246.000000
    75%       922.750000
    max      2272.000000
    Name: Total Time Spent on Website, dtype: float64




```python
sns.boxplot(lead_data['Total Time Spent on Website'],orient='vert',palette='Set1')
```




    <AxesSubplot:xlabel='Total Time Spent on Website'>




    
![png](output_82_1.png)
    



```python
sns.boxplot(y = 'Total Time Spent on Website', x = 'Converted', data = lead_data,palette='Set1')
```




    <AxesSubplot:xlabel='Converted', ylabel='Total Time Spent on Website'>




    
![png](output_83_1.png)
    


### Inference
* Leads spending more time on the weblise are more likely to be converted.

**Website should be made more engaging to make leads spend more time.**

### 8) Page Views Per Visit


```python
lead_data['Page Views Per Visit'].describe()
```




    count    9074.000000
    mean        2.370151
    std         2.160871
    min         0.000000
    25%         1.000000
    50%         2.000000
    75%         3.200000
    max        55.000000
    Name: Page Views Per Visit, dtype: float64




```python
sns.boxplot(lead_data['Page Views Per Visit'],orient='vert',palette='Set1')
```




    <AxesSubplot:xlabel='Page Views Per Visit'>




    
![png](output_87_1.png)
    


**As we can see there are a number of outliers in the data.
We will cap the outliers to 95% value for analysis.**


```python
percentiles = lead_data['Page Views Per Visit'].quantile([0.05,0.95]).values
lead_data['Page Views Per Visit'][lead_data['Page Views Per Visit'] <= percentiles[0]] = percentiles[0]
lead_data['Page Views Per Visit'][lead_data['Page Views Per Visit'] >= percentiles[1]] = percentiles[1]

```


```python
# Visualizing again
sns.boxplot(lead_data['Page Views Per Visit'],palette='Set1',orient='vert')
```




    <AxesSubplot:xlabel='Page Views Per Visit'>




    
![png](output_90_1.png)
    



```python
sns.boxplot(y = 'Page Views Per Visit', x = 'Converted', data =lead_data,palette='Set1')
```




    <AxesSubplot:xlabel='Converted', ylabel='Page Views Per Visit'>




    
![png](output_91_1.png)
    


### Inference
* Median for converted and unconverted leads is the same.

**Nothing can be said specifically for lead conversion from Page Views Per Visit**

### 9) Last Activity


```python
lead_data['Last Activity'].describe()
```




    count             9074
    unique              17
    top       Email Opened
    freq              3432
    Name: Last Activity, dtype: object




```python
plt.figure(figsize=(15,6))
sns.countplot(x = "Last Activity", hue = "Converted", data = lead_data,palette='Set1')
plt.xticks(rotation = 90)
```




    (array([ 0,  1,  2,  3,  4,  5,  6,  7,  8,  9, 10, 11, 12, 13, 14, 15, 16]),
     [Text(0, 0, 'Page Visited on Website'),
      Text(1, 0, 'Email Opened'),
      Text(2, 0, 'Unreachable'),
      Text(3, 0, 'Converted to Lead'),
      Text(4, 0, 'Olark Chat Conversation'),
      Text(5, 0, 'Email Bounced'),
      Text(6, 0, 'Email Link Clicked'),
      Text(7, 0, 'Form Submitted on Website'),
      Text(8, 0, 'Unsubscribed'),
      Text(9, 0, 'Had a Phone Conversation'),
      Text(10, 0, 'View in browser link Clicked'),
      Text(11, 0, 'SMS Sent'),
      Text(12, 0, 'Visited Booth in Tradeshow'),
      Text(13, 0, 'Approached upfront'),
      Text(14, 0, 'Resubscribed to emails'),
      Text(15, 0, 'Email Received'),
      Text(16, 0, 'Email Marked Spam')])




    
![png](output_95_1.png)
    



```python
# We can club the last activities to "Other_Activity" which are having less data.
lead_data['Last Activity'] = lead_data['Last Activity'].replace(['Had a Phone Conversation', 'View in browser link Clicked', 
                                                       'Visited Booth in Tradeshow', 'Approached upfront',
                                                       'Resubscribed to emails','Email Received', 'Email Marked Spam'], 'Other_Activity')
```


```python
# Visualizing again
plt.figure(figsize=(15,6))
sns.countplot(x = "Last Activity", hue = "Converted", data = lead_data,palette='Set1')
plt.xticks(rotation = 90)
```




    (array([ 0,  1,  2,  3,  4,  5,  6,  7,  8,  9, 10]),
     [Text(0, 0, 'Page Visited on Website'),
      Text(1, 0, 'Email Opened'),
      Text(2, 0, 'Unreachable'),
      Text(3, 0, 'Converted to Lead'),
      Text(4, 0, 'Olark Chat Conversation'),
      Text(5, 0, 'Email Bounced'),
      Text(6, 0, 'Email Link Clicked'),
      Text(7, 0, 'Form Submitted on Website'),
      Text(8, 0, 'Unsubscribed'),
      Text(9, 0, 'Other_Activity'),
      Text(10, 0, 'SMS Sent')])




    
![png](output_97_1.png)
    


### Inference
1. Most of the lead have their Email opened as their last activity.
2. Conversion rate for leads with last activity as SMS Sent is almost 60%.

### 10) Country


```python
plt.figure(figsize=(15,6))
sns.countplot(x = "Country", hue = "Converted", data = lead_data,palette='Set1')
plt.xticks(rotation = 90)
```




    (array([ 0,  1,  2,  3,  4,  5,  6,  7,  8,  9, 10, 11, 12, 13, 14, 15, 16,
            17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33,
            34, 35, 36, 37]),
     [Text(0, 0, 'India'),
      Text(1, 0, 'Russia'),
      Text(2, 0, 'Kuwait'),
      Text(3, 0, 'Oman'),
      Text(4, 0, 'United Arab Emirates'),
      Text(5, 0, 'United States'),
      Text(6, 0, 'Australia'),
      Text(7, 0, 'United Kingdom'),
      Text(8, 0, 'Bahrain'),
      Text(9, 0, 'Ghana'),
      Text(10, 0, 'Singapore'),
      Text(11, 0, 'Qatar'),
      Text(12, 0, 'Saudi Arabia'),
      Text(13, 0, 'Belgium'),
      Text(14, 0, 'France'),
      Text(15, 0, 'Sri Lanka'),
      Text(16, 0, 'China'),
      Text(17, 0, 'Canada'),
      Text(18, 0, 'Netherlands'),
      Text(19, 0, 'Sweden'),
      Text(20, 0, 'Nigeria'),
      Text(21, 0, 'Hong Kong'),
      Text(22, 0, 'Germany'),
      Text(23, 0, 'Asia/Pacific Region'),
      Text(24, 0, 'Uganda'),
      Text(25, 0, 'Kenya'),
      Text(26, 0, 'Italy'),
      Text(27, 0, 'South Africa'),
      Text(28, 0, 'Tanzania'),
      Text(29, 0, 'unknown'),
      Text(30, 0, 'Malaysia'),
      Text(31, 0, 'Liberia'),
      Text(32, 0, 'Switzerland'),
      Text(33, 0, 'Denmark'),
      Text(34, 0, 'Philippines'),
      Text(35, 0, 'Bangladesh'),
      Text(36, 0, 'Vietnam'),
      Text(37, 0, 'Indonesia')])




    
![png](output_100_1.png)
    


### Inference
**Most values are 'India' no such inference can be drawn**

### 11) Specialization


```python
plt.figure(figsize=(15,6))
sns.countplot(x = "Specialization", hue = "Converted", data = lead_data,palette='Set1')
plt.xticks(rotation = 90)
```




    (array([ 0,  1,  2,  3,  4,  5,  6,  7,  8,  9, 10, 11, 12, 13, 14, 15, 16,
            17, 18]),
     [Text(0, 0, 'Others'),
      Text(1, 0, 'Business Administration'),
      Text(2, 0, 'Media and Advertising'),
      Text(3, 0, 'Supply Chain Management'),
      Text(4, 0, 'IT Projects Management'),
      Text(5, 0, 'Finance Management'),
      Text(6, 0, 'Travel and Tourism'),
      Text(7, 0, 'Human Resource Management'),
      Text(8, 0, 'Marketing Management'),
      Text(9, 0, 'Banking, Investment And Insurance'),
      Text(10, 0, 'International Business'),
      Text(11, 0, 'E-COMMERCE'),
      Text(12, 0, 'Operations Management'),
      Text(13, 0, 'Retail Management'),
      Text(14, 0, 'Services Excellence'),
      Text(15, 0, 'Hospitality Management'),
      Text(16, 0, 'Rural and Agribusiness'),
      Text(17, 0, 'Healthcare Management'),
      Text(18, 0, 'E-Business')])




    
![png](output_103_1.png)
    


### Inference
**Focus should be more on the Specialization with high conversion rate.**

### 12) What is your current occupation


```python
plt.figure(figsize=(15,6))
sns.countplot(x = "What is your current occupation", hue = "Converted", data = lead_data,palette='Set1')
plt.xticks(rotation = 90)
```




    (array([0, 1, 2, 3, 4, 5]),
     [Text(0, 0, 'Unemployed'),
      Text(1, 0, 'Student'),
      Text(2, 0, 'Working Professional'),
      Text(3, 0, 'Businessman'),
      Text(4, 0, 'Other'),
      Text(5, 0, 'Housewife')])




    
![png](output_106_1.png)
    


### Inference
1. Working Professionals going for the course have high chances of joining it.
2. Unemployed leads are the most in numbers but has around 30-35% conversion rate.

### 13) Search


```python
sns.countplot(x = "Search", hue = "Converted", data = lead_data,palette='Set1')
plt.xticks(rotation = 90)
```




    (array([0, 1]), [Text(0, 0, 'No'), Text(1, 0, 'Yes')])




    
![png](output_109_1.png)
    


### Inference
Most entries are 'No'. No Inference can be drawn with this parameter.

### 14) Magazine


```python
sns.countplot(x = "Magazine", hue = "Converted", data = lead_data,palette='Set1')
plt.xticks(rotation = 90)
```




    (array([0]), [Text(0, 0, 'No')])




    
![png](output_112_1.png)
    


### Inference
Most entries are 'No'. No Inference can be drawn with this parameter.

### 15) Newspaper Article


```python
sns.countplot(x = "Newspaper Article", hue = "Converted", data = lead_data,palette='Set1')
plt.xticks(rotation = 90)
```




    (array([0, 1]), [Text(0, 0, 'No'), Text(1, 0, 'Yes')])




    
![png](output_115_1.png)
    


### Inference
Most entries are 'No'. No Inference can be drawn with this parameter.

### 16) X Education Forums


```python
sns.countplot(x = "X Education Forums", hue = "Converted", data = lead_data,palette='Set1')
plt.xticks(rotation = 90)
```




    (array([0, 1]), [Text(0, 0, 'No'), Text(1, 0, 'Yes')])




    
![png](output_118_1.png)
    


### Inference
Most entries are 'No'. No Inference can be drawn with this parameter.

### 17) Newspaper


```python
sns.countplot(x = "Newspaper", hue = "Converted", data = lead_data,palette='Set1')
plt.xticks(rotation = 90)
```




    (array([0, 1]), [Text(0, 0, 'No'), Text(1, 0, 'Yes')])




    
![png](output_121_1.png)
    


### Inference
Most entries are 'No'. No Inference can be drawn with this parameter.

### 18) Digital Advertisement


```python
sns.countplot(x = "Digital Advertisement", hue = "Converted", data = lead_data,palette='Set1')
plt.xticks(rotation = 90)
```




    (array([0, 1]), [Text(0, 0, 'No'), Text(1, 0, 'Yes')])




    
![png](output_124_1.png)
    


### Inference
Most entries are 'No'. No Inference can be drawn with this parameter.

### 19) Through Recommendations


```python
sns.countplot(x = "Through Recommendations", hue = "Converted", data = lead_data,palette='Set1')
plt.xticks(rotation = 90)
```




    (array([0, 1]), [Text(0, 0, 'No'), Text(1, 0, 'Yes')])




    
![png](output_127_1.png)
    


### Inference
Most entries are 'No'. No Inference can be drawn with this parameter.

### 20) Receive More Updates About Our Courses


```python
sns.countplot(x = "Receive More Updates About Our Courses", hue = "Converted", data = lead_data,palette='Set1')
plt.xticks(rotation = 90)
```




    (array([0]), [Text(0, 0, 'No')])




    
![png](output_130_1.png)
    


### Inference
Most entries are 'No'. No Inference can be drawn with this parameter.

### 21) Tags


```python
plt.figure(figsize=(15,6))
sns.countplot(x = "Tags", hue = "Converted", data = lead_data,palette='Set1')
plt.xticks(rotation = 90)
```




    (array([ 0,  1,  2,  3,  4,  5,  6,  7,  8,  9, 10, 11, 12, 13, 14, 15, 16,
            17, 18, 19, 20, 21, 22, 23, 24, 25]),
     [Text(0, 0, 'Interested in other courses'),
      Text(1, 0, 'Ringing'),
      Text(2, 0, 'Will revert after reading the email'),
      Text(3, 0, 'Lost to EINS'),
      Text(4, 0, 'In confusion whether part time or DLP'),
      Text(5, 0, 'Busy'),
      Text(6, 0, 'switched off'),
      Text(7, 0, 'in touch with EINS'),
      Text(8, 0, 'Already a student'),
      Text(9, 0, 'Diploma holder (Not Eligible)'),
      Text(10, 0, 'Graduation in progress'),
      Text(11, 0, 'number not provided'),
      Text(12, 0, 'opp hangup'),
      Text(13, 0, 'Closed by Horizzon'),
      Text(14, 0, 'Not doing further education'),
      Text(15, 0, 'invalid number'),
      Text(16, 0, 'wrong number given'),
      Text(17, 0, 'Interested  in full time MBA'),
      Text(18, 0, 'Still Thinking'),
      Text(19, 0, 'Lost to Others'),
      Text(20, 0, 'Shall take in the next coming month'),
      Text(21, 0, 'Lateral student'),
      Text(22, 0, 'Interested in Next batch'),
      Text(23, 0, 'Recognition issue (DEC approval)'),
      Text(24, 0, 'Want to take admission but has financial problems'),
      Text(25, 0, 'University not recognized')])




    
![png](output_133_1.png)
    


### Inference
Since this is a column which is generated by the sales team for their analysis , so this is not available for model building . So we will need to remove this column before building the model.

### 22) Update me on Supply Chain Content


```python
sns.countplot(x = "Update me on Supply Chain Content", hue = "Converted", data = lead_data,palette='Set1')
plt.xticks(rotation = 90)
```




    (array([0]), [Text(0, 0, 'No')])




    
![png](output_136_1.png)
    


### Inference
Most entries are 'No'. No Inference can be drawn with this parameter.

### 23) Get updates on DM Content


```python
sns.countplot(x = "Get updates on DM Content", hue = "Converted", data = lead_data,palette='Set1')
plt.xticks(rotation = 90)
```




    (array([0]), [Text(0, 0, 'No')])




    
![png](output_139_1.png)
    


### Inference
Most entries are 'No'. No Inference can be drawn with this parameter.

### 24) City


```python
plt.figure(figsize=(15,5))
sns.countplot(x = "City", hue = "Converted", data = lead_data,palette='Set1')
plt.xticks(rotation = 90)
```




    (array([0, 1, 2, 3, 4, 5]),
     [Text(0, 0, 'Mumbai'),
      Text(1, 0, 'Thane & Outskirts'),
      Text(2, 0, 'Other Metro Cities'),
      Text(3, 0, 'Other Cities'),
      Text(4, 0, 'Other Cities of Maharashtra'),
      Text(5, 0, 'Tier II Cities')])




    
![png](output_142_1.png)
    


### Inference
**Most leads are from mumbai with around 50% conversion rate.**

### 25) I agree to pay the amount through cheque


```python
sns.countplot(x = "I agree to pay the amount through cheque", hue = "Converted", data = lead_data,palette='Set1')
plt.xticks(rotation = 90)
```




    (array([0]), [Text(0, 0, 'No')])




    
![png](output_145_1.png)
    


### Inference
Most entries are 'No'. No Inference can be drawn with this parameter.

### 26) A free copy of Mastering The Interview


```python
sns.countplot(x = "A free copy of Mastering The Interview", hue = "Converted", data = lead_data,palette='Set1')
plt.xticks(rotation = 90)
```




    (array([0, 1]), [Text(0, 0, 'No'), Text(1, 0, 'Yes')])




    
![png](output_148_1.png)
    


### Inference
Most entries are 'No'. No Inference can be drawn with this parameter.

### 27) Last Notable Activity


```python
plt.figure(figsize=(15,5))
sns.countplot(x = "Last Notable Activity", hue = "Converted", data = lead_data,palette='Set1')
plt.xticks(rotation = 90)
```




    (array([ 0,  1,  2,  3,  4,  5,  6,  7,  8,  9, 10, 11, 12, 13, 14, 15]),
     [Text(0, 0, 'Modified'),
      Text(1, 0, 'Email Opened'),
      Text(2, 0, 'Page Visited on Website'),
      Text(3, 0, 'Email Bounced'),
      Text(4, 0, 'Email Link Clicked'),
      Text(5, 0, 'Unreachable'),
      Text(6, 0, 'Unsubscribed'),
      Text(7, 0, 'Had a Phone Conversation'),
      Text(8, 0, 'Olark Chat Conversation'),
      Text(9, 0, 'SMS Sent'),
      Text(10, 0, 'Approached upfront'),
      Text(11, 0, 'Resubscribed to emails'),
      Text(12, 0, 'View in browser link Clicked'),
      Text(13, 0, 'Form Submitted on Website'),
      Text(14, 0, 'Email Received'),
      Text(15, 0, 'Email Marked Spam')])




    
![png](output_151_1.png)
    


### Results
**Based on the univariate analysis we have seen that many columns are not adding any information to the model, hence we can drop them for further analysis**


```python
lead_data = lead_data.drop(['Lead Number','Tags','Country','Search','Magazine','Newspaper Article','X Education Forums',
                            'Newspaper','Digital Advertisement','Through Recommendations','Receive More Updates About Our Courses',
                            'Update me on Supply Chain Content','Get updates on DM Content','I agree to pay the amount through cheque',
                            'A free copy of Mastering The Interview'],1)
```


```python
lead_data.shape
```




    (9074, 14)




```python
lead_data.info()
```

    <class 'pandas.core.frame.DataFrame'>
    Int64Index: 9074 entries, 0 to 9239
    Data columns (total 14 columns):
     #   Column                           Non-Null Count  Dtype  
    ---  ------                           --------------  -----  
     0   Prospect ID                      9074 non-null   object 
     1   Lead Origin                      9074 non-null   object 
     2   Lead Source                      9074 non-null   object 
     3   Do Not Email                     9074 non-null   object 
     4   Do Not Call                      9074 non-null   object 
     5   Converted                        9074 non-null   int64  
     6   TotalVisits                      9074 non-null   float64
     7   Total Time Spent on Website      9074 non-null   int64  
     8   Page Views Per Visit             9074 non-null   float64
     9   Last Activity                    9074 non-null   object 
     10  Specialization                   9074 non-null   object 
     11  What is your current occupation  9074 non-null   object 
     12  City                             9074 non-null   object 
     13  Last Notable Activity            9074 non-null   object 
    dtypes: float64(2), int64(2), object(10)
    memory usage: 1.0+ MB
    

## Data Preparation

### 1) Converting some binary variables (Yes/No) to 1/0


```python
vars =  ['Do Not Email', 'Do Not Call']

def binary_map(x):
    return x.map({'Yes': 1, "No": 0})

lead_data[vars] = lead_data[vars].apply(binary_map)
```

### 2) Creating Dummy variables for the categorical features:
'Lead Origin', 'Lead Source', 'Last Activity', 'Specialization','What is your current occupation','City','Last Notable Activity'


```python
# Creating a dummy variable for the categorical variables and dropping the first one.
dummy_data = pd.get_dummies(lead_data[['Lead Origin', 'Lead Source', 'Last Activity', 'Specialization','What is your current occupation',
                             'City','Last Notable Activity']], drop_first=True)
dummy_data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Lead Origin_Landing Page Submission</th>
      <th>Lead Origin_Lead Add Form</th>
      <th>Lead Origin_Lead Import</th>
      <th>Lead Source_Facebook</th>
      <th>Lead Source_Google</th>
      <th>Lead Source_Olark Chat</th>
      <th>Lead Source_Organic Search</th>
      <th>Lead Source_Others</th>
      <th>Lead Source_Reference</th>
      <th>Lead Source_Referral Sites</th>
      <th>...</th>
      <th>Last Notable Activity_Form Submitted on Website</th>
      <th>Last Notable Activity_Had a Phone Conversation</th>
      <th>Last Notable Activity_Modified</th>
      <th>Last Notable Activity_Olark Chat Conversation</th>
      <th>Last Notable Activity_Page Visited on Website</th>
      <th>Last Notable Activity_Resubscribed to emails</th>
      <th>Last Notable Activity_SMS Sent</th>
      <th>Last Notable Activity_Unreachable</th>
      <th>Last Notable Activity_Unsubscribed</th>
      <th>Last Notable Activity_View in browser link Clicked</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 64 columns</p>
</div>




```python
# Concatenating the dummy_data to the lead_data dataframe
lead_data = pd.concat([lead_data, dummy_data], axis=1)
lead_data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Prospect ID</th>
      <th>Lead Origin</th>
      <th>Lead Source</th>
      <th>Do Not Email</th>
      <th>Do Not Call</th>
      <th>Converted</th>
      <th>TotalVisits</th>
      <th>Total Time Spent on Website</th>
      <th>Page Views Per Visit</th>
      <th>Last Activity</th>
      <th>...</th>
      <th>Last Notable Activity_Form Submitted on Website</th>
      <th>Last Notable Activity_Had a Phone Conversation</th>
      <th>Last Notable Activity_Modified</th>
      <th>Last Notable Activity_Olark Chat Conversation</th>
      <th>Last Notable Activity_Page Visited on Website</th>
      <th>Last Notable Activity_Resubscribed to emails</th>
      <th>Last Notable Activity_SMS Sent</th>
      <th>Last Notable Activity_Unreachable</th>
      <th>Last Notable Activity_Unsubscribed</th>
      <th>Last Notable Activity_View in browser link Clicked</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>7927b2df-8bba-4d29-b9a2-b6e0beafe620</td>
      <td>API</td>
      <td>Olark Chat</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0.0</td>
      <td>0</td>
      <td>0.0</td>
      <td>Page Visited on Website</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2a272436-5132-4136-86fa-dcc88c88f482</td>
      <td>API</td>
      <td>Organic Search</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>5.0</td>
      <td>674</td>
      <td>2.5</td>
      <td>Email Opened</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>8cc8c611-a219-4f35-ad23-fdfd2656bd8a</td>
      <td>Landing Page Submission</td>
      <td>Direct Traffic</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>2.0</td>
      <td>1532</td>
      <td>2.0</td>
      <td>Email Opened</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0cc2df48-7cf4-4e39-9de9-19797f9b38cc</td>
      <td>Landing Page Submission</td>
      <td>Direct Traffic</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1.0</td>
      <td>305</td>
      <td>1.0</td>
      <td>Unreachable</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>3256f628-e534-4826-9d63-4a8b88782852</td>
      <td>Landing Page Submission</td>
      <td>Google</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>2.0</td>
      <td>1428</td>
      <td>1.0</td>
      <td>Converted to Lead</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 78 columns</p>
</div>



**Dropping the columns for which dummies were created**


```python
lead_data = lead_data.drop(['Lead Origin', 'Lead Source', 'Last Activity', 'Specialization','What is your current occupation',
                             'City','Last Notable Activity'], axis = 1)
```


```python
lead_data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Prospect ID</th>
      <th>Do Not Email</th>
      <th>Do Not Call</th>
      <th>Converted</th>
      <th>TotalVisits</th>
      <th>Total Time Spent on Website</th>
      <th>Page Views Per Visit</th>
      <th>Lead Origin_Landing Page Submission</th>
      <th>Lead Origin_Lead Add Form</th>
      <th>Lead Origin_Lead Import</th>
      <th>...</th>
      <th>Last Notable Activity_Form Submitted on Website</th>
      <th>Last Notable Activity_Had a Phone Conversation</th>
      <th>Last Notable Activity_Modified</th>
      <th>Last Notable Activity_Olark Chat Conversation</th>
      <th>Last Notable Activity_Page Visited on Website</th>
      <th>Last Notable Activity_Resubscribed to emails</th>
      <th>Last Notable Activity_SMS Sent</th>
      <th>Last Notable Activity_Unreachable</th>
      <th>Last Notable Activity_Unsubscribed</th>
      <th>Last Notable Activity_View in browser link Clicked</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>7927b2df-8bba-4d29-b9a2-b6e0beafe620</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0.0</td>
      <td>0</td>
      <td>0.0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2a272436-5132-4136-86fa-dcc88c88f482</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>5.0</td>
      <td>674</td>
      <td>2.5</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>8cc8c611-a219-4f35-ad23-fdfd2656bd8a</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>2.0</td>
      <td>1532</td>
      <td>2.0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0cc2df48-7cf4-4e39-9de9-19797f9b38cc</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1.0</td>
      <td>305</td>
      <td>1.0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>3256f628-e534-4826-9d63-4a8b88782852</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>2.0</td>
      <td>1428</td>
      <td>1.0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 71 columns</p>
</div>



### 3) Splitting the data into  train and test set.


```python
from sklearn.model_selection import train_test_split

# Putting feature variable to X
X = lead_data.drop(['Prospect ID','Converted'], axis=1)
X.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Do Not Email</th>
      <th>Do Not Call</th>
      <th>TotalVisits</th>
      <th>Total Time Spent on Website</th>
      <th>Page Views Per Visit</th>
      <th>Lead Origin_Landing Page Submission</th>
      <th>Lead Origin_Lead Add Form</th>
      <th>Lead Origin_Lead Import</th>
      <th>Lead Source_Facebook</th>
      <th>Lead Source_Google</th>
      <th>...</th>
      <th>Last Notable Activity_Form Submitted on Website</th>
      <th>Last Notable Activity_Had a Phone Conversation</th>
      <th>Last Notable Activity_Modified</th>
      <th>Last Notable Activity_Olark Chat Conversation</th>
      <th>Last Notable Activity_Page Visited on Website</th>
      <th>Last Notable Activity_Resubscribed to emails</th>
      <th>Last Notable Activity_SMS Sent</th>
      <th>Last Notable Activity_Unreachable</th>
      <th>Last Notable Activity_Unsubscribed</th>
      <th>Last Notable Activity_View in browser link Clicked</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>0</td>
      <td>0.0</td>
      <td>0</td>
      <td>0.0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0</td>
      <td>0</td>
      <td>5.0</td>
      <td>674</td>
      <td>2.5</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0</td>
      <td>0</td>
      <td>2.0</td>
      <td>1532</td>
      <td>2.0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0</td>
      <td>0</td>
      <td>1.0</td>
      <td>305</td>
      <td>1.0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0</td>
      <td>0</td>
      <td>2.0</td>
      <td>1428</td>
      <td>1.0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 69 columns</p>
</div>




```python
# Putting target variable to y
y = lead_data['Converted']

y.head()
```




    0    0
    1    0
    2    1
    3    0
    4    1
    Name: Converted, dtype: int64




```python
# Splitting the data into train and test
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.7, test_size=0.3, random_state=100)
```

### 4)  Scaling the features


```python
from sklearn.preprocessing import StandardScaler

scaler = StandardScaler()

X_train[['TotalVisits','Total Time Spent on Website','Page Views Per Visit']] = scaler.fit_transform(X_train[['TotalVisits','Total Time Spent on Website','Page Views Per Visit']])

X_train.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Do Not Email</th>
      <th>Do Not Call</th>
      <th>TotalVisits</th>
      <th>Total Time Spent on Website</th>
      <th>Page Views Per Visit</th>
      <th>Lead Origin_Landing Page Submission</th>
      <th>Lead Origin_Lead Add Form</th>
      <th>Lead Origin_Lead Import</th>
      <th>Lead Source_Facebook</th>
      <th>Lead Source_Google</th>
      <th>...</th>
      <th>Last Notable Activity_Form Submitted on Website</th>
      <th>Last Notable Activity_Had a Phone Conversation</th>
      <th>Last Notable Activity_Modified</th>
      <th>Last Notable Activity_Olark Chat Conversation</th>
      <th>Last Notable Activity_Page Visited on Website</th>
      <th>Last Notable Activity_Resubscribed to emails</th>
      <th>Last Notable Activity_SMS Sent</th>
      <th>Last Notable Activity_Unreachable</th>
      <th>Last Notable Activity_Unsubscribed</th>
      <th>Last Notable Activity_View in browser link Clicked</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>3009</th>
      <td>0</td>
      <td>0</td>
      <td>-0.432779</td>
      <td>-0.160255</td>
      <td>-0.155018</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1012</th>
      <td>1</td>
      <td>0</td>
      <td>-0.432779</td>
      <td>-0.540048</td>
      <td>-0.155018</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>9226</th>
      <td>0</td>
      <td>0</td>
      <td>-1.150329</td>
      <td>-0.888650</td>
      <td>-1.265540</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4750</th>
      <td>0</td>
      <td>0</td>
      <td>-0.432779</td>
      <td>1.643304</td>
      <td>-0.155018</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>7987</th>
      <td>0</td>
      <td>0</td>
      <td>0.643547</td>
      <td>2.017593</td>
      <td>0.122613</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 69 columns</p>
</div>




```python
# Checking the Lead Conversion rate
Converted = (sum(lead_data['Converted'])/len(lead_data['Converted'].index))*100
Converted
```




    37.85541106458012



We have almost 38% lead conversion rate.

## Feature Selection Using RFE


```python
from sklearn.linear_model import LogisticRegression
logreg = LogisticRegression()

from sklearn.feature_selection import RFE
rfe = RFE(logreg, n_features_to_select=20)             # running RFE with 20 variables as output
rfe = rfe.fit(X_train, y_train)
```


```python
rfe.support_
```




    array([ True,  True, False,  True, False,  True,  True,  True, False,
           False,  True, False, False,  True, False,  True, False,  True,
            True, False,  True,  True, False,  True,  True,  True, False,
           False, False, False, False,  True, False, False, False, False,
           False, False,  True, False, False, False, False, False,  True,
           False,  True,  True,  True, False, False, False, False,  True,
            True,  True, False,  True, False, False,  True,  True,  True,
            True, False,  True,  True,  True,  True])




```python
list(zip(X_train.columns, rfe.support_, rfe.ranking_))
```




    [('Do Not Email', True, 1),
     ('Do Not Call', True, 1),
     ('TotalVisits', False, 2),
     ('Total Time Spent on Website', True, 1),
     ('Page Views Per Visit', False, 2),
     ('Lead Origin_Landing Page Submission', True, 1),
     ('Lead Origin_Lead Add Form', True, 1),
     ('Lead Origin_Lead Import', True, 1),
     ('Lead Source_Facebook', False, 2),
     ('Lead Source_Google', False, 2),
     ('Lead Source_Olark Chat', True, 1),
     ('Lead Source_Organic Search', False, 3),
     ('Lead Source_Others', False, 2),
     ('Lead Source_Reference', True, 1),
     ('Lead Source_Referral Sites', False, 3),
     ('Lead Source_Welingak Website', True, 1),
     ('Last Activity_Email Bounced', False, 2),
     ('Last Activity_Email Link Clicked', True, 1),
     ('Last Activity_Email Opened', True, 1),
     ('Last Activity_Form Submitted on Website', False, 3),
     ('Last Activity_Olark Chat Conversation', True, 1),
     ('Last Activity_Other_Activity', True, 1),
     ('Last Activity_Page Visited on Website', False, 2),
     ('Last Activity_SMS Sent', True, 1),
     ('Last Activity_Unreachable', True, 1),
     ('Last Activity_Unsubscribed', True, 1),
     ('Specialization_Business Administration', False, 2),
     ('Specialization_E-Business', False, 2),
     ('Specialization_E-COMMERCE', False, 3),
     ('Specialization_Finance Management', False, 3),
     ('Specialization_Healthcare Management', False, 3),
     ('Specialization_Hospitality Management', True, 1),
     ('Specialization_Human Resource Management', False, 3),
     ('Specialization_IT Projects Management', False, 3),
     ('Specialization_International Business', False, 2),
     ('Specialization_Marketing Management', False, 3),
     ('Specialization_Media and Advertising', False, 2),
     ('Specialization_Operations Management', False, 3),
     ('Specialization_Others', True, 1),
     ('Specialization_Retail Management', False, 2),
     ('Specialization_Rural and Agribusiness', False, 3),
     ('Specialization_Services Excellence', False, 2),
     ('Specialization_Supply Chain Management', False, 3),
     ('Specialization_Travel and Tourism', False, 2),
     ('What is your current occupation_Housewife', True, 1),
     ('What is your current occupation_Other', False, 3),
     ('What is your current occupation_Student', True, 1),
     ('What is your current occupation_Unemployed', True, 1),
     ('What is your current occupation_Working Professional', True, 1),
     ('City_Other Cities', False, 3),
     ('City_Other Cities of Maharashtra', False, 3),
     ('City_Other Metro Cities', False, 3),
     ('City_Thane & Outskirts', False, 3),
     ('City_Tier II Cities', True, 1),
     ('Last Notable Activity_Email Bounced', True, 1),
     ('Last Notable Activity_Email Link Clicked', True, 1),
     ('Last Notable Activity_Email Marked Spam', False, 3),
     ('Last Notable Activity_Email Opened', True, 1),
     ('Last Notable Activity_Email Received', False, 3),
     ('Last Notable Activity_Form Submitted on Website', False, 3),
     ('Last Notable Activity_Had a Phone Conversation', True, 1),
     ('Last Notable Activity_Modified', True, 1),
     ('Last Notable Activity_Olark Chat Conversation', True, 1),
     ('Last Notable Activity_Page Visited on Website', True, 1),
     ('Last Notable Activity_Resubscribed to emails', False, 2),
     ('Last Notable Activity_SMS Sent', True, 1),
     ('Last Notable Activity_Unreachable', True, 1),
     ('Last Notable Activity_Unsubscribed', True, 1),
     ('Last Notable Activity_View in browser link Clicked', True, 1)]




```python
# Viewing columns selected by RFE
cols = X_train.columns[rfe.support_]
cols
```




    Index(['Do Not Email', 'Do Not Call', 'Total Time Spent on Website',
           'Lead Origin_Landing Page Submission', 'Lead Origin_Lead Add Form',
           'Lead Origin_Lead Import', 'Lead Source_Olark Chat',
           'Lead Source_Reference', 'Lead Source_Welingak Website',
           'Last Activity_Email Link Clicked', 'Last Activity_Email Opened',
           'Last Activity_Olark Chat Conversation', 'Last Activity_Other_Activity',
           'Last Activity_SMS Sent', 'Last Activity_Unreachable',
           'Last Activity_Unsubscribed', 'Specialization_Hospitality Management',
           'Specialization_Others', 'What is your current occupation_Housewife',
           'What is your current occupation_Student',
           'What is your current occupation_Unemployed',
           'What is your current occupation_Working Professional',
           'City_Tier II Cities', 'Last Notable Activity_Email Bounced',
           'Last Notable Activity_Email Link Clicked',
           'Last Notable Activity_Email Opened',
           'Last Notable Activity_Had a Phone Conversation',
           'Last Notable Activity_Modified',
           'Last Notable Activity_Olark Chat Conversation',
           'Last Notable Activity_Page Visited on Website',
           'Last Notable Activity_SMS Sent', 'Last Notable Activity_Unreachable',
           'Last Notable Activity_Unsubscribed',
           'Last Notable Activity_View in browser link Clicked'],
          dtype='object')



## Model Building

### Assessing the model with StatsModels

### Model-1


```python
import statsmodels.api as sm
```


```python
X_train_sm = sm.add_constant(X_train[cols])
logm1 = sm.GLM(y_train,X_train_sm, family = sm.families.Binomial())
result = logm1.fit()
result.summary()
```




<table class="simpletable">
<caption>Generalized Linear Model Regression Results</caption>
<tr>
  <th>Dep. Variable:</th>       <td>Converted</td>    <th>  No. Observations:  </th>  <td>  6351</td> 
</tr>
<tr>
  <th>Model:</th>                  <td>GLM</td>       <th>  Df Residuals:      </th>  <td>  6316</td> 
</tr>
<tr>
  <th>Model Family:</th>        <td>Binomial</td>     <th>  Df Model:          </th>  <td>    34</td> 
</tr>
<tr>
  <th>Link Function:</th>         <td>Logit</td>      <th>  Scale:             </th> <td>  1.0000</td>
</tr>
<tr>
  <th>Method:</th>                <td>IRLS</td>       <th>  Log-Likelihood:    </th> <td> -2567.6</td>
</tr>
<tr>
  <th>Date:</th>            <td>Thu, 15 Jun 2023</td> <th>  Deviance:          </th> <td>  5135.2</td>
</tr>
<tr>
  <th>Time:</th>                <td>21:32:10</td>     <th>  Pearson chi2:      </th> <td>6.39e+03</td>
</tr>
<tr>
  <th>No. Iterations:</th>         <td>21</td>        <th>  Pseudo R-squ. (CS):</th>  <td>0.4081</td> 
</tr>
<tr>
  <th>Covariance Type:</th>     <td>nonrobust</td>    <th>                     </th>     <td> </td>   
</tr>
</table>
<table class="simpletable">
<tr>
                            <td></td>                              <th>coef</th>     <th>std err</th>      <th>z</th>      <th>P>|z|</th>  <th>[0.025</th>    <th>0.975]</th>  
</tr>
<tr>
  <th>const</th>                                                <td>    1.6007</td> <td>    1.661</td> <td>    0.964</td> <td> 0.335</td> <td>   -1.654</td> <td>    4.855</td>
</tr>
<tr>
  <th>Do Not Email</th>                                         <td>   -1.6564</td> <td>    0.210</td> <td>   -7.881</td> <td> 0.000</td> <td>   -2.068</td> <td>   -1.244</td>
</tr>
<tr>
  <th>Do Not Call</th>                                          <td>   21.6137</td> <td>  3.3e+04</td> <td>    0.001</td> <td> 0.999</td> <td>-6.47e+04</td> <td> 6.47e+04</td>
</tr>
<tr>
  <th>Total Time Spent on Website</th>                          <td>    1.1101</td> <td>    0.041</td> <td>   26.997</td> <td> 0.000</td> <td>    1.030</td> <td>    1.191</td>
</tr>
<tr>
  <th>Lead Origin_Landing Page Submission</th>                  <td>   -1.1126</td> <td>    0.130</td> <td>   -8.531</td> <td> 0.000</td> <td>   -1.368</td> <td>   -0.857</td>
</tr>
<tr>
  <th>Lead Origin_Lead Add Form</th>                            <td>    1.4997</td> <td>    0.889</td> <td>    1.686</td> <td> 0.092</td> <td>   -0.244</td> <td>    3.243</td>
</tr>
<tr>
  <th>Lead Origin_Lead Import</th>                              <td>    0.9100</td> <td>    0.477</td> <td>    1.909</td> <td> 0.056</td> <td>   -0.024</td> <td>    1.844</td>
</tr>
<tr>
  <th>Lead Source_Olark Chat</th>                               <td>    1.1030</td> <td>    0.125</td> <td>    8.854</td> <td> 0.000</td> <td>    0.859</td> <td>    1.347</td>
</tr>
<tr>
  <th>Lead Source_Reference</th>                                <td>    1.8289</td> <td>    0.914</td> <td>    2.001</td> <td> 0.045</td> <td>    0.038</td> <td>    3.620</td>
</tr>
<tr>
  <th>Lead Source_Welingak Website</th>                         <td>    4.4013</td> <td>    1.147</td> <td>    3.838</td> <td> 0.000</td> <td>    2.154</td> <td>    6.649</td>
</tr>
<tr>
  <th>Last Activity_Email Link Clicked</th>                     <td>    0.4575</td> <td>    0.396</td> <td>    1.156</td> <td> 0.248</td> <td>   -0.318</td> <td>    1.233</td>
</tr>
<tr>
  <th>Last Activity_Email Opened</th>                           <td>    0.6642</td> <td>    0.185</td> <td>    3.598</td> <td> 0.000</td> <td>    0.302</td> <td>    1.026</td>
</tr>
<tr>
  <th>Last Activity_Olark Chat Conversation</th>                <td>   -0.6190</td> <td>    0.227</td> <td>   -2.733</td> <td> 0.006</td> <td>   -1.063</td> <td>   -0.175</td>
</tr>
<tr>
  <th>Last Activity_Other_Activity</th>                         <td>    2.1619</td> <td>    0.603</td> <td>    3.587</td> <td> 0.000</td> <td>    0.981</td> <td>    3.343</td>
</tr>
<tr>
  <th>Last Activity_SMS Sent</th>                               <td>    1.1159</td> <td>    0.187</td> <td>    5.978</td> <td> 0.000</td> <td>    0.750</td> <td>    1.482</td>
</tr>
<tr>
  <th>Last Activity_Unreachable</th>                            <td>    0.2990</td> <td>    0.509</td> <td>    0.588</td> <td> 0.557</td> <td>   -0.698</td> <td>    1.296</td>
</tr>
<tr>
  <th>Last Activity_Unsubscribed</th>                           <td>    1.3943</td> <td>    1.125</td> <td>    1.240</td> <td> 0.215</td> <td>   -0.810</td> <td>    3.598</td>
</tr>
<tr>
  <th>Specialization_Hospitality Management</th>                <td>   -0.4284</td> <td>    0.329</td> <td>   -1.303</td> <td> 0.193</td> <td>   -1.073</td> <td>    0.216</td>
</tr>
<tr>
  <th>Specialization_Others</th>                                <td>   -1.1435</td> <td>    0.127</td> <td>   -9.022</td> <td> 0.000</td> <td>   -1.392</td> <td>   -0.895</td>
</tr>
<tr>
  <th>What is your current occupation_Housewife</th>            <td>   21.7279</td> <td> 1.53e+04</td> <td>    0.001</td> <td> 0.999</td> <td>-2.99e+04</td> <td>    3e+04</td>
</tr>
<tr>
  <th>What is your current occupation_Student</th>              <td>   -0.5905</td> <td>    0.687</td> <td>   -0.859</td> <td> 0.390</td> <td>   -1.938</td> <td>    0.757</td>
</tr>
<tr>
  <th>What is your current occupation_Unemployed</th>           <td>   -1.0375</td> <td>    0.649</td> <td>   -1.599</td> <td> 0.110</td> <td>   -2.309</td> <td>    0.234</td>
</tr>
<tr>
  <th>What is your current occupation_Working Professional</th> <td>    1.5918</td> <td>    0.675</td> <td>    2.359</td> <td> 0.018</td> <td>    0.269</td> <td>    2.914</td>
</tr>
<tr>
  <th>City_Tier II Cities</th>                                  <td>   -0.5652</td> <td>    0.456</td> <td>   -1.240</td> <td> 0.215</td> <td>   -1.458</td> <td>    0.328</td>
</tr>
<tr>
  <th>Last Notable Activity_Email Bounced</th>                  <td>   -0.4072</td> <td>    1.621</td> <td>   -0.251</td> <td> 0.802</td> <td>   -3.584</td> <td>    2.769</td>
</tr>
<tr>
  <th>Last Notable Activity_Email Link Clicked</th>             <td>   -1.6374</td> <td>    1.591</td> <td>   -1.029</td> <td> 0.304</td> <td>   -4.756</td> <td>    1.482</td>
</tr>
<tr>
  <th>Last Notable Activity_Email Opened</th>                   <td>   -1.4060</td> <td>    1.534</td> <td>   -0.917</td> <td> 0.359</td> <td>   -4.412</td> <td>    1.600</td>
</tr>
<tr>
  <th>Last Notable Activity_Had a Phone Conversation</th>       <td>    0.3877</td> <td>    1.871</td> <td>    0.207</td> <td> 0.836</td> <td>   -3.280</td> <td>    4.056</td>
</tr>
<tr>
  <th>Last Notable Activity_Modified</th>                       <td>   -1.7704</td> <td>    1.527</td> <td>   -1.159</td> <td> 0.246</td> <td>   -4.764</td> <td>    1.223</td>
</tr>
<tr>
  <th>Last Notable Activity_Olark Chat Conversation</th>        <td>   -1.4961</td> <td>    1.571</td> <td>   -0.953</td> <td> 0.341</td> <td>   -4.574</td> <td>    1.582</td>
</tr>
<tr>
  <th>Last Notable Activity_Page Visited on Website</th>        <td>   -1.0096</td> <td>    1.540</td> <td>   -0.656</td> <td> 0.512</td> <td>   -4.027</td> <td>    2.008</td>
</tr>
<tr>
  <th>Last Notable Activity_SMS Sent</th>                       <td>   -0.3921</td> <td>    1.534</td> <td>   -0.256</td> <td> 0.798</td> <td>   -3.399</td> <td>    2.615</td>
</tr>
<tr>
  <th>Last Notable Activity_Unreachable</th>                    <td>    0.5416</td> <td>    1.673</td> <td>    0.324</td> <td> 0.746</td> <td>   -2.737</td> <td>    3.820</td>
</tr>
<tr>
  <th>Last Notable Activity_Unsubscribed</th>                   <td>   -0.6983</td> <td>    1.952</td> <td>   -0.358</td> <td> 0.720</td> <td>   -4.523</td> <td>    3.127</td>
</tr>
<tr>
  <th>Last Notable Activity_View in browser link Clicked</th>   <td>  -24.4859</td> <td> 4.82e+04</td> <td>   -0.001</td> <td> 1.000</td> <td>-9.45e+04</td> <td> 9.44e+04</td>
</tr>
</table>



Since Pvalue of 'What is your current occupation_Housewife' is very high, we can drop this column.


```python
# Dropping the column 'What is your current occupation_Housewife'
col1 = cols.drop('What is your current occupation_Housewife')
```

### Model-2


```python
X_train_sm = sm.add_constant(X_train[col1])
logm2 = sm.GLM(y_train,X_train_sm, family = sm.families.Binomial())
res = logm2.fit()
res.summary()
```




<table class="simpletable">
<caption>Generalized Linear Model Regression Results</caption>
<tr>
  <th>Dep. Variable:</th>       <td>Converted</td>    <th>  No. Observations:  </th>  <td>  6351</td> 
</tr>
<tr>
  <th>Model:</th>                  <td>GLM</td>       <th>  Df Residuals:      </th>  <td>  6317</td> 
</tr>
<tr>
  <th>Model Family:</th>        <td>Binomial</td>     <th>  Df Model:          </th>  <td>    33</td> 
</tr>
<tr>
  <th>Link Function:</th>         <td>Logit</td>      <th>  Scale:             </th> <td>  1.0000</td>
</tr>
<tr>
  <th>Method:</th>                <td>IRLS</td>       <th>  Log-Likelihood:    </th> <td> -2569.5</td>
</tr>
<tr>
  <th>Date:</th>            <td>Thu, 15 Jun 2023</td> <th>  Deviance:          </th> <td>  5139.0</td>
</tr>
<tr>
  <th>Time:</th>                <td>21:32:36</td>     <th>  Pearson chi2:      </th> <td>6.40e+03</td>
</tr>
<tr>
  <th>No. Iterations:</th>         <td>20</td>        <th>  Pseudo R-squ. (CS):</th>  <td>0.4078</td> 
</tr>
<tr>
  <th>Covariance Type:</th>     <td>nonrobust</td>    <th>                     </th>     <td> </td>   
</tr>
</table>
<table class="simpletable">
<tr>
                            <td></td>                              <th>coef</th>     <th>std err</th>      <th>z</th>      <th>P>|z|</th>  <th>[0.025</th>    <th>0.975]</th>  
</tr>
<tr>
  <th>const</th>                                                <td>    2.0893</td> <td>    1.642</td> <td>    1.272</td> <td> 0.203</td> <td>   -1.129</td> <td>    5.307</td>
</tr>
<tr>
  <th>Do Not Email</th>                                         <td>   -1.6601</td> <td>    0.210</td> <td>   -7.893</td> <td> 0.000</td> <td>   -2.072</td> <td>   -1.248</td>
</tr>
<tr>
  <th>Do Not Call</th>                                          <td>   20.6175</td> <td>    2e+04</td> <td>    0.001</td> <td> 0.999</td> <td>-3.92e+04</td> <td> 3.93e+04</td>
</tr>
<tr>
  <th>Total Time Spent on Website</th>                          <td>    1.1090</td> <td>    0.041</td> <td>   26.988</td> <td> 0.000</td> <td>    1.028</td> <td>    1.190</td>
</tr>
<tr>
  <th>Lead Origin_Landing Page Submission</th>                  <td>   -1.1060</td> <td>    0.130</td> <td>   -8.488</td> <td> 0.000</td> <td>   -1.361</td> <td>   -0.851</td>
</tr>
<tr>
  <th>Lead Origin_Lead Add Form</th>                            <td>    1.5026</td> <td>    0.889</td> <td>    1.690</td> <td> 0.091</td> <td>   -0.240</td> <td>    3.246</td>
</tr>
<tr>
  <th>Lead Origin_Lead Import</th>                              <td>    0.9113</td> <td>    0.477</td> <td>    1.913</td> <td> 0.056</td> <td>   -0.023</td> <td>    1.845</td>
</tr>
<tr>
  <th>Lead Source_Olark Chat</th>                               <td>    1.1031</td> <td>    0.125</td> <td>    8.854</td> <td> 0.000</td> <td>    0.859</td> <td>    1.347</td>
</tr>
<tr>
  <th>Lead Source_Reference</th>                                <td>    1.8312</td> <td>    0.914</td> <td>    2.004</td> <td> 0.045</td> <td>    0.041</td> <td>    3.622</td>
</tr>
<tr>
  <th>Lead Source_Welingak Website</th>                         <td>    4.3991</td> <td>    1.147</td> <td>    3.836</td> <td> 0.000</td> <td>    2.151</td> <td>    6.647</td>
</tr>
<tr>
  <th>Last Activity_Email Link Clicked</th>                     <td>    0.4630</td> <td>    0.396</td> <td>    1.170</td> <td> 0.242</td> <td>   -0.313</td> <td>    1.239</td>
</tr>
<tr>
  <th>Last Activity_Email Opened</th>                           <td>    0.6694</td> <td>    0.185</td> <td>    3.625</td> <td> 0.000</td> <td>    0.307</td> <td>    1.031</td>
</tr>
<tr>
  <th>Last Activity_Olark Chat Conversation</th>                <td>   -0.6158</td> <td>    0.227</td> <td>   -2.716</td> <td> 0.007</td> <td>   -1.060</td> <td>   -0.171</td>
</tr>
<tr>
  <th>Last Activity_Other_Activity</th>                         <td>    2.1672</td> <td>    0.603</td> <td>    3.596</td> <td> 0.000</td> <td>    0.986</td> <td>    3.348</td>
</tr>
<tr>
  <th>Last Activity_SMS Sent</th>                               <td>    1.1207</td> <td>    0.187</td> <td>    6.002</td> <td> 0.000</td> <td>    0.755</td> <td>    1.487</td>
</tr>
<tr>
  <th>Last Activity_Unreachable</th>                            <td>    0.3037</td> <td>    0.509</td> <td>    0.597</td> <td> 0.550</td> <td>   -0.693</td> <td>    1.301</td>
</tr>
<tr>
  <th>Last Activity_Unsubscribed</th>                           <td>    1.4012</td> <td>    1.124</td> <td>    1.246</td> <td> 0.213</td> <td>   -0.803</td> <td>    3.605</td>
</tr>
<tr>
  <th>Specialization_Hospitality Management</th>                <td>   -0.4286</td> <td>    0.329</td> <td>   -1.304</td> <td> 0.192</td> <td>   -1.073</td> <td>    0.216</td>
</tr>
<tr>
  <th>Specialization_Others</th>                                <td>   -1.1398</td> <td>    0.127</td> <td>   -9.000</td> <td> 0.000</td> <td>   -1.388</td> <td>   -0.892</td>
</tr>
<tr>
  <th>What is your current occupation_Student</th>              <td>   -1.0879</td> <td>    0.638</td> <td>   -1.706</td> <td> 0.088</td> <td>   -2.338</td> <td>    0.162</td>
</tr>
<tr>
  <th>What is your current occupation_Unemployed</th>           <td>   -1.5340</td> <td>    0.596</td> <td>   -2.573</td> <td> 0.010</td> <td>   -2.703</td> <td>   -0.365</td>
</tr>
<tr>
  <th>What is your current occupation_Working Professional</th> <td>    1.0951</td> <td>    0.624</td> <td>    1.754</td> <td> 0.079</td> <td>   -0.128</td> <td>    2.319</td>
</tr>
<tr>
  <th>City_Tier II Cities</th>                                  <td>   -0.5651</td> <td>    0.456</td> <td>   -1.240</td> <td> 0.215</td> <td>   -1.458</td> <td>    0.328</td>
</tr>
<tr>
  <th>Last Notable Activity_Email Bounced</th>                  <td>   -0.4003</td> <td>    1.621</td> <td>   -0.247</td> <td> 0.805</td> <td>   -3.577</td> <td>    2.777</td>
</tr>
<tr>
  <th>Last Notable Activity_Email Link Clicked</th>             <td>   -1.6377</td> <td>    1.592</td> <td>   -1.029</td> <td> 0.304</td> <td>   -4.757</td> <td>    1.482</td>
</tr>
<tr>
  <th>Last Notable Activity_Email Opened</th>                   <td>   -1.4062</td> <td>    1.534</td> <td>   -0.917</td> <td> 0.359</td> <td>   -4.413</td> <td>    1.601</td>
</tr>
<tr>
  <th>Last Notable Activity_Had a Phone Conversation</th>       <td>    0.3843</td> <td>    1.872</td> <td>    0.205</td> <td> 0.837</td> <td>   -3.284</td> <td>    4.053</td>
</tr>
<tr>
  <th>Last Notable Activity_Modified</th>                       <td>   -1.7728</td> <td>    1.528</td> <td>   -1.160</td> <td> 0.246</td> <td>   -4.767</td> <td>    1.221</td>
</tr>
<tr>
  <th>Last Notable Activity_Olark Chat Conversation</th>        <td>   -1.4949</td> <td>    1.571</td> <td>   -0.952</td> <td> 0.341</td> <td>   -4.574</td> <td>    1.584</td>
</tr>
<tr>
  <th>Last Notable Activity_Page Visited on Website</th>        <td>   -1.0108</td> <td>    1.540</td> <td>   -0.656</td> <td> 0.512</td> <td>   -4.029</td> <td>    2.008</td>
</tr>
<tr>
  <th>Last Notable Activity_SMS Sent</th>                       <td>   -0.3942</td> <td>    1.535</td> <td>   -0.257</td> <td> 0.797</td> <td>   -3.402</td> <td>    2.614</td>
</tr>
<tr>
  <th>Last Notable Activity_Unreachable</th>                    <td>    0.5371</td> <td>    1.673</td> <td>    0.321</td> <td> 0.748</td> <td>   -2.743</td> <td>    3.817</td>
</tr>
<tr>
  <th>Last Notable Activity_Unsubscribed</th>                   <td>   -0.6979</td> <td>    1.952</td> <td>   -0.358</td> <td> 0.721</td> <td>   -4.523</td> <td>    3.127</td>
</tr>
<tr>
  <th>Last Notable Activity_View in browser link Clicked</th>   <td>  -23.4840</td> <td> 2.92e+04</td> <td>   -0.001</td> <td> 0.999</td> <td>-5.73e+04</td> <td> 5.73e+04</td>
</tr>
</table>



Since Pvalue of 'Last Notable Activity_Had a Phone Conversation' is very high, we can drop this column.


```python
col1 = col1.drop('Last Notable Activity_Had a Phone Conversation')
```

### Model-3


```python
X_train_sm = sm.add_constant(X_train[col1])
logm3 = sm.GLM(y_train,X_train_sm, family = sm.families.Binomial())
res = logm3.fit()
res.summary()
```




<table class="simpletable">
<caption>Generalized Linear Model Regression Results</caption>
<tr>
  <th>Dep. Variable:</th>       <td>Converted</td>    <th>  No. Observations:  </th>  <td>  6351</td> 
</tr>
<tr>
  <th>Model:</th>                  <td>GLM</td>       <th>  Df Residuals:      </th>  <td>  6318</td> 
</tr>
<tr>
  <th>Model Family:</th>        <td>Binomial</td>     <th>  Df Model:          </th>  <td>    32</td> 
</tr>
<tr>
  <th>Link Function:</th>         <td>Logit</td>      <th>  Scale:             </th> <td>  1.0000</td>
</tr>
<tr>
  <th>Method:</th>                <td>IRLS</td>       <th>  Log-Likelihood:    </th> <td> -2569.5</td>
</tr>
<tr>
  <th>Date:</th>            <td>Thu, 15 Jun 2023</td> <th>  Deviance:          </th> <td>  5139.1</td>
</tr>
<tr>
  <th>Time:</th>                <td>21:32:45</td>     <th>  Pearson chi2:      </th> <td>6.40e+03</td>
</tr>
<tr>
  <th>No. Iterations:</th>         <td>20</td>        <th>  Pseudo R-squ. (CS):</th>  <td>0.4078</td> 
</tr>
<tr>
  <th>Covariance Type:</th>     <td>nonrobust</td>    <th>                     </th>     <td> </td>   
</tr>
</table>
<table class="simpletable">
<tr>
                            <td></td>                              <th>coef</th>     <th>std err</th>      <th>z</th>      <th>P>|z|</th>  <th>[0.025</th>    <th>0.975]</th>  
</tr>
<tr>
  <th>const</th>                                                <td>    2.3292</td> <td>    1.165</td> <td>    1.999</td> <td> 0.046</td> <td>    0.045</td> <td>    4.613</td>
</tr>
<tr>
  <th>Do Not Email</th>                                         <td>   -1.6609</td> <td>    0.210</td> <td>   -7.894</td> <td> 0.000</td> <td>   -2.073</td> <td>   -1.248</td>
</tr>
<tr>
  <th>Do Not Call</th>                                          <td>   20.6173</td> <td>    2e+04</td> <td>    0.001</td> <td> 0.999</td> <td>-3.92e+04</td> <td> 3.93e+04</td>
</tr>
<tr>
  <th>Total Time Spent on Website</th>                          <td>    1.1089</td> <td>    0.041</td> <td>   26.987</td> <td> 0.000</td> <td>    1.028</td> <td>    1.189</td>
</tr>
<tr>
  <th>Lead Origin_Landing Page Submission</th>                  <td>   -1.1062</td> <td>    0.130</td> <td>   -8.491</td> <td> 0.000</td> <td>   -1.362</td> <td>   -0.851</td>
</tr>
<tr>
  <th>Lead Origin_Lead Add Form</th>                            <td>    1.5025</td> <td>    0.889</td> <td>    1.690</td> <td> 0.091</td> <td>   -0.240</td> <td>    3.245</td>
</tr>
<tr>
  <th>Lead Origin_Lead Import</th>                              <td>    0.9110</td> <td>    0.477</td> <td>    1.912</td> <td> 0.056</td> <td>   -0.023</td> <td>    1.845</td>
</tr>
<tr>
  <th>Lead Source_Olark Chat</th>                               <td>    1.1026</td> <td>    0.125</td> <td>    8.852</td> <td> 0.000</td> <td>    0.858</td> <td>    1.347</td>
</tr>
<tr>
  <th>Lead Source_Reference</th>                                <td>    1.8308</td> <td>    0.914</td> <td>    2.004</td> <td> 0.045</td> <td>    0.040</td> <td>    3.621</td>
</tr>
<tr>
  <th>Lead Source_Welingak Website</th>                         <td>    4.3992</td> <td>    1.147</td> <td>    3.836</td> <td> 0.000</td> <td>    2.152</td> <td>    6.647</td>
</tr>
<tr>
  <th>Last Activity_Email Link Clicked</th>                     <td>    0.4639</td> <td>    0.396</td> <td>    1.172</td> <td> 0.241</td> <td>   -0.312</td> <td>    1.240</td>
</tr>
<tr>
  <th>Last Activity_Email Opened</th>                           <td>    0.6702</td> <td>    0.185</td> <td>    3.631</td> <td> 0.000</td> <td>    0.308</td> <td>    1.032</td>
</tr>
<tr>
  <th>Last Activity_Olark Chat Conversation</th>                <td>   -0.6148</td> <td>    0.227</td> <td>   -2.712</td> <td> 0.007</td> <td>   -1.059</td> <td>   -0.170</td>
</tr>
<tr>
  <th>Last Activity_Other_Activity</th>                         <td>    2.1863</td> <td>    0.595</td> <td>    3.673</td> <td> 0.000</td> <td>    1.020</td> <td>    3.353</td>
</tr>
<tr>
  <th>Last Activity_SMS Sent</th>                               <td>    1.1216</td> <td>    0.187</td> <td>    6.008</td> <td> 0.000</td> <td>    0.756</td> <td>    1.487</td>
</tr>
<tr>
  <th>Last Activity_Unreachable</th>                            <td>    0.3045</td> <td>    0.509</td> <td>    0.599</td> <td> 0.549</td> <td>   -0.693</td> <td>    1.302</td>
</tr>
<tr>
  <th>Last Activity_Unsubscribed</th>                           <td>    1.4024</td> <td>    1.124</td> <td>    1.247</td> <td> 0.212</td> <td>   -0.801</td> <td>    3.606</td>
</tr>
<tr>
  <th>Specialization_Hospitality Management</th>                <td>   -0.4286</td> <td>    0.329</td> <td>   -1.303</td> <td> 0.192</td> <td>   -1.073</td> <td>    0.216</td>
</tr>
<tr>
  <th>Specialization_Others</th>                                <td>   -1.1401</td> <td>    0.127</td> <td>   -9.003</td> <td> 0.000</td> <td>   -1.388</td> <td>   -0.892</td>
</tr>
<tr>
  <th>What is your current occupation_Student</th>              <td>   -1.0880</td> <td>    0.638</td> <td>   -1.706</td> <td> 0.088</td> <td>   -2.338</td> <td>    0.162</td>
</tr>
<tr>
  <th>What is your current occupation_Unemployed</th>           <td>   -1.5342</td> <td>    0.596</td> <td>   -2.573</td> <td> 0.010</td> <td>   -2.703</td> <td>   -0.365</td>
</tr>
<tr>
  <th>What is your current occupation_Working Professional</th> <td>    1.0948</td> <td>    0.624</td> <td>    1.754</td> <td> 0.079</td> <td>   -0.129</td> <td>    2.318</td>
</tr>
<tr>
  <th>City_Tier II Cities</th>                                  <td>   -0.5649</td> <td>    0.456</td> <td>   -1.240</td> <td> 0.215</td> <td>   -1.458</td> <td>    0.328</td>
</tr>
<tr>
  <th>Last Notable Activity_Email Bounced</th>                  <td>   -0.6390</td> <td>    1.143</td> <td>   -0.559</td> <td> 0.576</td> <td>   -2.879</td> <td>    1.601</td>
</tr>
<tr>
  <th>Last Notable Activity_Email Link Clicked</th>             <td>   -1.8780</td> <td>    1.092</td> <td>   -1.719</td> <td> 0.086</td> <td>   -4.019</td> <td>    0.263</td>
</tr>
<tr>
  <th>Last Notable Activity_Email Opened</th>                   <td>   -1.6465</td> <td>    1.006</td> <td>   -1.636</td> <td> 0.102</td> <td>   -3.619</td> <td>    0.326</td>
</tr>
<tr>
  <th>Last Notable Activity_Modified</th>                       <td>   -2.0130</td> <td>    0.997</td> <td>   -2.020</td> <td> 0.043</td> <td>   -3.966</td> <td>   -0.060</td>
</tr>
<tr>
  <th>Last Notable Activity_Olark Chat Conversation</th>        <td>   -1.7351</td> <td>    1.062</td> <td>   -1.634</td> <td> 0.102</td> <td>   -3.817</td> <td>    0.346</td>
</tr>
<tr>
  <th>Last Notable Activity_Page Visited on Website</th>        <td>   -1.2502</td> <td>    1.020</td> <td>   -1.226</td> <td> 0.220</td> <td>   -3.249</td> <td>    0.748</td>
</tr>
<tr>
  <th>Last Notable Activity_SMS Sent</th>                       <td>   -0.6345</td> <td>    1.007</td> <td>   -0.630</td> <td> 0.529</td> <td>   -2.609</td> <td>    1.340</td>
</tr>
<tr>
  <th>Last Notable Activity_Unreachable</th>                    <td>    0.2968</td> <td>    1.208</td> <td>    0.246</td> <td> 0.806</td> <td>   -2.071</td> <td>    2.664</td>
</tr>
<tr>
  <th>Last Notable Activity_Unsubscribed</th>                   <td>   -0.9379</td> <td>    1.573</td> <td>   -0.596</td> <td> 0.551</td> <td>   -4.021</td> <td>    2.145</td>
</tr>
<tr>
  <th>Last Notable Activity_View in browser link Clicked</th>   <td>  -23.7430</td> <td> 2.92e+04</td> <td>   -0.001</td> <td> 0.999</td> <td>-5.73e+04</td> <td> 5.73e+04</td>
</tr>
</table>



Since Pvalue of 'What is your current occupation_Student' is very high, we can drop this column.


```python
col1 = col1.drop('What is your current occupation_Student')
```

### Model-4


```python
X_train_sm = sm.add_constant(X_train[col1])
logm4 = sm.GLM(y_train,X_train_sm, family = sm.families.Binomial())
res = logm4.fit()
res.summary()
```




<table class="simpletable">
<caption>Generalized Linear Model Regression Results</caption>
<tr>
  <th>Dep. Variable:</th>       <td>Converted</td>    <th>  No. Observations:  </th>  <td>  6351</td> 
</tr>
<tr>
  <th>Model:</th>                  <td>GLM</td>       <th>  Df Residuals:      </th>  <td>  6319</td> 
</tr>
<tr>
  <th>Model Family:</th>        <td>Binomial</td>     <th>  Df Model:          </th>  <td>    31</td> 
</tr>
<tr>
  <th>Link Function:</th>         <td>Logit</td>      <th>  Scale:             </th> <td>  1.0000</td>
</tr>
<tr>
  <th>Method:</th>                <td>IRLS</td>       <th>  Log-Likelihood:    </th> <td> -2571.1</td>
</tr>
<tr>
  <th>Date:</th>            <td>Thu, 15 Jun 2023</td> <th>  Deviance:          </th> <td>  5142.1</td>
</tr>
<tr>
  <th>Time:</th>                <td>21:32:53</td>     <th>  Pearson chi2:      </th> <td>6.40e+03</td>
</tr>
<tr>
  <th>No. Iterations:</th>         <td>20</td>        <th>  Pseudo R-squ. (CS):</th>  <td>0.4075</td> 
</tr>
<tr>
  <th>Covariance Type:</th>     <td>nonrobust</td>    <th>                     </th>     <td> </td>   
</tr>
</table>
<table class="simpletable">
<tr>
                            <td></td>                              <th>coef</th>     <th>std err</th>      <th>z</th>      <th>P>|z|</th>  <th>[0.025</th>    <th>0.975]</th>  
</tr>
<tr>
  <th>const</th>                                                <td>    1.4073</td> <td>    1.029</td> <td>    1.368</td> <td> 0.171</td> <td>   -0.609</td> <td>    3.423</td>
</tr>
<tr>
  <th>Do Not Email</th>                                         <td>   -1.6564</td> <td>    0.210</td> <td>   -7.882</td> <td> 0.000</td> <td>   -2.068</td> <td>   -1.245</td>
</tr>
<tr>
  <th>Do Not Call</th>                                          <td>   20.6024</td> <td>    2e+04</td> <td>    0.001</td> <td> 0.999</td> <td>-3.92e+04</td> <td> 3.93e+04</td>
</tr>
<tr>
  <th>Total Time Spent on Website</th>                          <td>    1.1097</td> <td>    0.041</td> <td>   27.014</td> <td> 0.000</td> <td>    1.029</td> <td>    1.190</td>
</tr>
<tr>
  <th>Lead Origin_Landing Page Submission</th>                  <td>   -1.1198</td> <td>    0.130</td> <td>   -8.611</td> <td> 0.000</td> <td>   -1.375</td> <td>   -0.865</td>
</tr>
<tr>
  <th>Lead Origin_Lead Add Form</th>                            <td>    1.4962</td> <td>    0.889</td> <td>    1.683</td> <td> 0.092</td> <td>   -0.247</td> <td>    3.239</td>
</tr>
<tr>
  <th>Lead Origin_Lead Import</th>                              <td>    0.9041</td> <td>    0.477</td> <td>    1.896</td> <td> 0.058</td> <td>   -0.030</td> <td>    1.839</td>
</tr>
<tr>
  <th>Lead Source_Olark Chat</th>                               <td>    1.0976</td> <td>    0.124</td> <td>    8.818</td> <td> 0.000</td> <td>    0.854</td> <td>    1.342</td>
</tr>
<tr>
  <th>Lead Source_Reference</th>                                <td>    1.8375</td> <td>    0.914</td> <td>    2.011</td> <td> 0.044</td> <td>    0.047</td> <td>    3.628</td>
</tr>
<tr>
  <th>Lead Source_Welingak Website</th>                         <td>    4.4053</td> <td>    1.147</td> <td>    3.842</td> <td> 0.000</td> <td>    2.158</td> <td>    6.653</td>
</tr>
<tr>
  <th>Last Activity_Email Link Clicked</th>                     <td>    0.4509</td> <td>    0.396</td> <td>    1.139</td> <td> 0.255</td> <td>   -0.325</td> <td>    1.226</td>
</tr>
<tr>
  <th>Last Activity_Email Opened</th>                           <td>    0.6625</td> <td>    0.184</td> <td>    3.593</td> <td> 0.000</td> <td>    0.301</td> <td>    1.024</td>
</tr>
<tr>
  <th>Last Activity_Olark Chat Conversation</th>                <td>   -0.6185</td> <td>    0.226</td> <td>   -2.733</td> <td> 0.006</td> <td>   -1.062</td> <td>   -0.175</td>
</tr>
<tr>
  <th>Last Activity_Other_Activity</th>                         <td>    2.1819</td> <td>    0.595</td> <td>    3.665</td> <td> 0.000</td> <td>    1.015</td> <td>    3.349</td>
</tr>
<tr>
  <th>Last Activity_SMS Sent</th>                               <td>    1.1157</td> <td>    0.187</td> <td>    5.980</td> <td> 0.000</td> <td>    0.750</td> <td>    1.481</td>
</tr>
<tr>
  <th>Last Activity_Unreachable</th>                            <td>    0.2980</td> <td>    0.509</td> <td>    0.586</td> <td> 0.558</td> <td>   -0.699</td> <td>    1.295</td>
</tr>
<tr>
  <th>Last Activity_Unsubscribed</th>                           <td>    1.3936</td> <td>    1.125</td> <td>    1.239</td> <td> 0.215</td> <td>   -0.810</td> <td>    3.598</td>
</tr>
<tr>
  <th>Specialization_Hospitality Management</th>                <td>   -0.4362</td> <td>    0.329</td> <td>   -1.327</td> <td> 0.184</td> <td>   -1.080</td> <td>    0.208</td>
</tr>
<tr>
  <th>Specialization_Others</th>                                <td>   -1.1526</td> <td>    0.126</td> <td>   -9.116</td> <td> 0.000</td> <td>   -1.400</td> <td>   -0.905</td>
</tr>
<tr>
  <th>What is your current occupation_Unemployed</th>           <td>   -0.5963</td> <td>    0.214</td> <td>   -2.793</td> <td> 0.005</td> <td>   -1.015</td> <td>   -0.178</td>
</tr>
<tr>
  <th>What is your current occupation_Working Professional</th> <td>    2.0314</td> <td>    0.284</td> <td>    7.145</td> <td> 0.000</td> <td>    1.474</td> <td>    2.589</td>
</tr>
<tr>
  <th>City_Tier II Cities</th>                                  <td>   -0.5654</td> <td>    0.456</td> <td>   -1.241</td> <td> 0.215</td> <td>   -1.458</td> <td>    0.328</td>
</tr>
<tr>
  <th>Last Notable Activity_Email Bounced</th>                  <td>   -0.6504</td> <td>    1.143</td> <td>   -0.569</td> <td> 0.569</td> <td>   -2.890</td> <td>    1.589</td>
</tr>
<tr>
  <th>Last Notable Activity_Email Link Clicked</th>             <td>   -1.8688</td> <td>    1.092</td> <td>   -1.711</td> <td> 0.087</td> <td>   -4.009</td> <td>    0.272</td>
</tr>
<tr>
  <th>Last Notable Activity_Email Opened</th>                   <td>   -1.6420</td> <td>    1.006</td> <td>   -1.632</td> <td> 0.103</td> <td>   -3.614</td> <td>    0.330</td>
</tr>
<tr>
  <th>Last Notable Activity_Modified</th>                       <td>   -2.0100</td> <td>    0.997</td> <td>   -2.017</td> <td> 0.044</td> <td>   -3.963</td> <td>   -0.057</td>
</tr>
<tr>
  <th>Last Notable Activity_Olark Chat Conversation</th>        <td>   -1.7423</td> <td>    1.062</td> <td>   -1.640</td> <td> 0.101</td> <td>   -3.824</td> <td>    0.339</td>
</tr>
<tr>
  <th>Last Notable Activity_Page Visited on Website</th>        <td>   -1.2496</td> <td>    1.020</td> <td>   -1.226</td> <td> 0.220</td> <td>   -3.248</td> <td>    0.749</td>
</tr>
<tr>
  <th>Last Notable Activity_SMS Sent</th>                       <td>   -0.6330</td> <td>    1.007</td> <td>   -0.628</td> <td> 0.530</td> <td>   -2.607</td> <td>    1.341</td>
</tr>
<tr>
  <th>Last Notable Activity_Unreachable</th>                    <td>    0.3055</td> <td>    1.208</td> <td>    0.253</td> <td> 0.800</td> <td>   -2.061</td> <td>    2.672</td>
</tr>
<tr>
  <th>Last Notable Activity_Unsubscribed</th>                   <td>   -0.9371</td> <td>    1.573</td> <td>   -0.596</td> <td> 0.551</td> <td>   -4.020</td> <td>    2.146</td>
</tr>
<tr>
  <th>Last Notable Activity_View in browser link Clicked</th>   <td>  -23.7540</td> <td> 2.92e+04</td> <td>   -0.001</td> <td> 0.999</td> <td>-5.73e+04</td> <td> 5.73e+04</td>
</tr>
</table>



Since Pvalue of 'Lead Origin_Lead Add Form' is very high, we can drop this column.



```python

col1 = col1.drop('Lead Origin_Lead Add Form')
```

### Model-5


```python
X_train_sm = sm.add_constant(X_train[col1])
logm5 = sm.GLM(y_train,X_train_sm, family = sm.families.Binomial())
res = logm5.fit()
res.summary()
```




<table class="simpletable">
<caption>Generalized Linear Model Regression Results</caption>
<tr>
  <th>Dep. Variable:</th>       <td>Converted</td>    <th>  No. Observations:  </th>  <td>  6351</td> 
</tr>
<tr>
  <th>Model:</th>                  <td>GLM</td>       <th>  Df Residuals:      </th>  <td>  6320</td> 
</tr>
<tr>
  <th>Model Family:</th>        <td>Binomial</td>     <th>  Df Model:          </th>  <td>    30</td> 
</tr>
<tr>
  <th>Link Function:</th>         <td>Logit</td>      <th>  Scale:             </th> <td>  1.0000</td>
</tr>
<tr>
  <th>Method:</th>                <td>IRLS</td>       <th>  Log-Likelihood:    </th> <td> -2572.6</td>
</tr>
<tr>
  <th>Date:</th>            <td>Thu, 15 Jun 2023</td> <th>  Deviance:          </th> <td>  5145.3</td>
</tr>
<tr>
  <th>Time:</th>                <td>21:33:03</td>     <th>  Pearson chi2:      </th> <td>6.40e+03</td>
</tr>
<tr>
  <th>No. Iterations:</th>         <td>20</td>        <th>  Pseudo R-squ. (CS):</th>  <td>0.4072</td> 
</tr>
<tr>
  <th>Covariance Type:</th>     <td>nonrobust</td>    <th>                     </th>     <td> </td>   
</tr>
</table>
<table class="simpletable">
<tr>
                            <td></td>                              <th>coef</th>     <th>std err</th>      <th>z</th>      <th>P>|z|</th>  <th>[0.025</th>    <th>0.975]</th>  
</tr>
<tr>
  <th>const</th>                                                <td>    1.4243</td> <td>    1.028</td> <td>    1.385</td> <td> 0.166</td> <td>   -0.591</td> <td>    3.440</td>
</tr>
<tr>
  <th>Do Not Email</th>                                         <td>   -1.6588</td> <td>    0.210</td> <td>   -7.894</td> <td> 0.000</td> <td>   -2.071</td> <td>   -1.247</td>
</tr>
<tr>
  <th>Do Not Call</th>                                          <td>   20.5939</td> <td>    2e+04</td> <td>    0.001</td> <td> 0.999</td> <td>-3.92e+04</td> <td> 3.92e+04</td>
</tr>
<tr>
  <th>Total Time Spent on Website</th>                          <td>    1.1077</td> <td>    0.041</td> <td>   27.009</td> <td> 0.000</td> <td>    1.027</td> <td>    1.188</td>
</tr>
<tr>
  <th>Lead Origin_Landing Page Submission</th>                  <td>   -1.1386</td> <td>    0.130</td> <td>   -8.778</td> <td> 0.000</td> <td>   -1.393</td> <td>   -0.884</td>
</tr>
<tr>
  <th>Lead Origin_Lead Import</th>                              <td>    0.8877</td> <td>    0.477</td> <td>    1.861</td> <td> 0.063</td> <td>   -0.047</td> <td>    1.823</td>
</tr>
<tr>
  <th>Lead Source_Olark Chat</th>                               <td>    1.0910</td> <td>    0.124</td> <td>    8.783</td> <td> 0.000</td> <td>    0.848</td> <td>    1.334</td>
</tr>
<tr>
  <th>Lead Source_Reference</th>                                <td>    3.3192</td> <td>    0.244</td> <td>   13.618</td> <td> 0.000</td> <td>    2.841</td> <td>    3.797</td>
</tr>
<tr>
  <th>Lead Source_Welingak Website</th>                         <td>    5.8929</td> <td>    0.731</td> <td>    8.062</td> <td> 0.000</td> <td>    4.460</td> <td>    7.325</td>
</tr>
<tr>
  <th>Last Activity_Email Link Clicked</th>                     <td>    0.4465</td> <td>    0.396</td> <td>    1.129</td> <td> 0.259</td> <td>   -0.329</td> <td>    1.222</td>
</tr>
<tr>
  <th>Last Activity_Email Opened</th>                           <td>    0.6636</td> <td>    0.184</td> <td>    3.603</td> <td> 0.000</td> <td>    0.303</td> <td>    1.025</td>
</tr>
<tr>
  <th>Last Activity_Olark Chat Conversation</th>                <td>   -0.6247</td> <td>    0.226</td> <td>   -2.762</td> <td> 0.006</td> <td>   -1.068</td> <td>   -0.181</td>
</tr>
<tr>
  <th>Last Activity_Other_Activity</th>                         <td>    2.1779</td> <td>    0.595</td> <td>    3.661</td> <td> 0.000</td> <td>    1.012</td> <td>    3.344</td>
</tr>
<tr>
  <th>Last Activity_SMS Sent</th>                               <td>    1.1122</td> <td>    0.186</td> <td>    5.967</td> <td> 0.000</td> <td>    0.747</td> <td>    1.477</td>
</tr>
<tr>
  <th>Last Activity_Unreachable</th>                            <td>    0.2952</td> <td>    0.509</td> <td>    0.580</td> <td> 0.562</td> <td>   -0.702</td> <td>    1.292</td>
</tr>
<tr>
  <th>Last Activity_Unsubscribed</th>                           <td>    1.3918</td> <td>    1.124</td> <td>    1.238</td> <td> 0.216</td> <td>   -0.812</td> <td>    3.595</td>
</tr>
<tr>
  <th>Specialization_Hospitality Management</th>                <td>   -0.4377</td> <td>    0.329</td> <td>   -1.332</td> <td> 0.183</td> <td>   -1.082</td> <td>    0.207</td>
</tr>
<tr>
  <th>Specialization_Others</th>                                <td>   -1.1650</td> <td>    0.126</td> <td>   -9.223</td> <td> 0.000</td> <td>   -1.413</td> <td>   -0.917</td>
</tr>
<tr>
  <th>What is your current occupation_Unemployed</th>           <td>   -0.5933</td> <td>    0.214</td> <td>   -2.778</td> <td> 0.005</td> <td>   -1.012</td> <td>   -0.175</td>
</tr>
<tr>
  <th>What is your current occupation_Working Professional</th> <td>    2.0311</td> <td>    0.284</td> <td>    7.142</td> <td> 0.000</td> <td>    1.474</td> <td>    2.588</td>
</tr>
<tr>
  <th>City_Tier II Cities</th>                                  <td>   -0.5656</td> <td>    0.455</td> <td>   -1.242</td> <td> 0.214</td> <td>   -1.458</td> <td>    0.327</td>
</tr>
<tr>
  <th>Last Notable Activity_Email Bounced</th>                  <td>   -0.6504</td> <td>    1.142</td> <td>   -0.569</td> <td> 0.569</td> <td>   -2.890</td> <td>    1.589</td>
</tr>
<tr>
  <th>Last Notable Activity_Email Link Clicked</th>             <td>   -1.8670</td> <td>    1.092</td> <td>   -1.710</td> <td> 0.087</td> <td>   -4.007</td> <td>    0.273</td>
</tr>
<tr>
  <th>Last Notable Activity_Email Opened</th>                   <td>   -1.6436</td> <td>    1.006</td> <td>   -1.634</td> <td> 0.102</td> <td>   -3.615</td> <td>    0.328</td>
</tr>
<tr>
  <th>Last Notable Activity_Modified</th>                       <td>   -2.0088</td> <td>    0.996</td> <td>   -2.016</td> <td> 0.044</td> <td>   -3.962</td> <td>   -0.056</td>
</tr>
<tr>
  <th>Last Notable Activity_Olark Chat Conversation</th>        <td>   -1.7389</td> <td>    1.062</td> <td>   -1.638</td> <td> 0.101</td> <td>   -3.820</td> <td>    0.342</td>
</tr>
<tr>
  <th>Last Notable Activity_Page Visited on Website</th>        <td>   -1.2425</td> <td>    1.019</td> <td>   -1.219</td> <td> 0.223</td> <td>   -3.240</td> <td>    0.755</td>
</tr>
<tr>
  <th>Last Notable Activity_SMS Sent</th>                       <td>   -0.6286</td> <td>    1.007</td> <td>   -0.624</td> <td> 0.533</td> <td>   -2.603</td> <td>    1.345</td>
</tr>
<tr>
  <th>Last Notable Activity_Unreachable</th>                    <td>    0.3041</td> <td>    1.207</td> <td>    0.252</td> <td> 0.801</td> <td>   -2.062</td> <td>    2.671</td>
</tr>
<tr>
  <th>Last Notable Activity_Unsubscribed</th>                   <td>   -0.9361</td> <td>    1.573</td> <td>   -0.595</td> <td> 0.552</td> <td>   -4.018</td> <td>    2.146</td>
</tr>
<tr>
  <th>Last Notable Activity_View in browser link Clicked</th>   <td>  -23.7715</td> <td> 2.92e+04</td> <td>   -0.001</td> <td> 0.999</td> <td>-5.73e+04</td> <td> 5.73e+04</td>
</tr>
</table>



### Checking for VIF values:


```python
# Check for the VIF values of the feature variables. 
from statsmodels.stats.outliers_influence import variance_inflation_factor

# Create a dataframe that will contain the names of all the feature variables and their respective VIFs
vif = pd.DataFrame()
vif['Features'] = X_train[col1].columns
vif['VIF'] = [variance_inflation_factor(X_train[col1].values, i) for i in range(X_train[col1].shape[1])]
vif['VIF'] = round(vif['VIF'], 2)
vif = vif.sort_values(by = "VIF", ascending = False)
vif
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Features</th>
      <th>VIF</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>17</th>
      <td>What is your current occupation_Unemployed</td>
      <td>34.18</td>
    </tr>
    <tr>
      <th>22</th>
      <td>Last Notable Activity_Email Opened</td>
      <td>22.25</td>
    </tr>
    <tr>
      <th>23</th>
      <td>Last Notable Activity_Modified</td>
      <td>19.91</td>
    </tr>
    <tr>
      <th>26</th>
      <td>Last Notable Activity_SMS Sent</td>
      <td>18.17</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Last Activity_Email Opened</td>
      <td>9.21</td>
    </tr>
    <tr>
      <th>12</th>
      <td>Last Activity_SMS Sent</td>
      <td>7.63</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Lead Origin_Landing Page Submission</td>
      <td>7.27</td>
    </tr>
    <tr>
      <th>16</th>
      <td>Specialization_Others</td>
      <td>4.66</td>
    </tr>
    <tr>
      <th>18</th>
      <td>What is your current occupation_Working Profes...</td>
      <td>3.93</td>
    </tr>
    <tr>
      <th>21</th>
      <td>Last Notable Activity_Email Link Clicked</td>
      <td>3.92</td>
    </tr>
    <tr>
      <th>28</th>
      <td>Last Notable Activity_Unsubscribed</td>
      <td>3.81</td>
    </tr>
    <tr>
      <th>14</th>
      <td>Last Activity_Unsubscribed</td>
      <td>3.62</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Last Activity_Email Link Clicked</td>
      <td>3.18</td>
    </tr>
    <tr>
      <th>25</th>
      <td>Last Notable Activity_Page Visited on Website</td>
      <td>2.61</td>
    </tr>
    <tr>
      <th>10</th>
      <td>Last Activity_Olark Chat Conversation</td>
      <td>2.58</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Lead Source_Olark Chat</td>
      <td>2.35</td>
    </tr>
    <tr>
      <th>24</th>
      <td>Last Notable Activity_Olark Chat Conversation</td>
      <td>2.27</td>
    </tr>
    <tr>
      <th>27</th>
      <td>Last Notable Activity_Unreachable</td>
      <td>1.79</td>
    </tr>
    <tr>
      <th>13</th>
      <td>Last Activity_Unreachable</td>
      <td>1.69</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Lead Source_Reference</td>
      <td>1.58</td>
    </tr>
    <tr>
      <th>20</th>
      <td>Last Notable Activity_Email Bounced</td>
      <td>1.48</td>
    </tr>
    <tr>
      <th>0</th>
      <td>Do Not Email</td>
      <td>1.47</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Total Time Spent on Website</td>
      <td>1.34</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Lead Source_Welingak Website</td>
      <td>1.12</td>
    </tr>
    <tr>
      <th>11</th>
      <td>Last Activity_Other_Activity</td>
      <td>1.11</td>
    </tr>
    <tr>
      <th>29</th>
      <td>Last Notable Activity_View in browser link Cli...</td>
      <td>1.03</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Lead Origin_Lead Import</td>
      <td>1.03</td>
    </tr>
    <tr>
      <th>19</th>
      <td>City_Tier II Cities</td>
      <td>1.02</td>
    </tr>
    <tr>
      <th>15</th>
      <td>Specialization_Hospitality Management</td>
      <td>1.02</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Do Not Call</td>
      <td>1.01</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Dropping the column  'What is your current occupation_Unemployed' because it has high VIF
col1 = col1.drop('What is your current occupation_Unemployed')
```

### Model-6


```python
X_train_sm = sm.add_constant(X_train[col1])
logm5 = sm.GLM(y_train,X_train_sm, family = sm.families.Binomial())
res = logm5.fit()
res.summary()
```




<table class="simpletable">
<caption>Generalized Linear Model Regression Results</caption>
<tr>
  <th>Dep. Variable:</th>       <td>Converted</td>    <th>  No. Observations:  </th>  <td>  6351</td> 
</tr>
<tr>
  <th>Model:</th>                  <td>GLM</td>       <th>  Df Residuals:      </th>  <td>  6321</td> 
</tr>
<tr>
  <th>Model Family:</th>        <td>Binomial</td>     <th>  Df Model:          </th>  <td>    29</td> 
</tr>
<tr>
  <th>Link Function:</th>         <td>Logit</td>      <th>  Scale:             </th> <td>  1.0000</td>
</tr>
<tr>
  <th>Method:</th>                <td>IRLS</td>       <th>  Log-Likelihood:    </th> <td> -2576.4</td>
</tr>
<tr>
  <th>Date:</th>            <td>Thu, 15 Jun 2023</td> <th>  Deviance:          </th> <td>  5152.8</td>
</tr>
<tr>
  <th>Time:</th>                <td>21:33:20</td>     <th>  Pearson chi2:      </th> <td>6.42e+03</td>
</tr>
<tr>
  <th>No. Iterations:</th>         <td>20</td>        <th>  Pseudo R-squ. (CS):</th>  <td>0.4065</td> 
</tr>
<tr>
  <th>Covariance Type:</th>     <td>nonrobust</td>    <th>                     </th>     <td> </td>   
</tr>
</table>
<table class="simpletable">
<tr>
                            <td></td>                              <th>coef</th>     <th>std err</th>      <th>z</th>      <th>P>|z|</th>  <th>[0.025</th>    <th>0.975]</th>  
</tr>
<tr>
  <th>const</th>                                                <td>    0.8416</td> <td>    1.006</td> <td>    0.836</td> <td> 0.403</td> <td>   -1.131</td> <td>    2.814</td>
</tr>
<tr>
  <th>Do Not Email</th>                                         <td>   -1.6518</td> <td>    0.210</td> <td>   -7.850</td> <td> 0.000</td> <td>   -2.064</td> <td>   -1.239</td>
</tr>
<tr>
  <th>Do Not Call</th>                                          <td>   20.5595</td> <td>    2e+04</td> <td>    0.001</td> <td> 0.999</td> <td>-3.92e+04</td> <td> 3.93e+04</td>
</tr>
<tr>
  <th>Total Time Spent on Website</th>                          <td>    1.1077</td> <td>    0.041</td> <td>   27.021</td> <td> 0.000</td> <td>    1.027</td> <td>    1.188</td>
</tr>
<tr>
  <th>Lead Origin_Landing Page Submission</th>                  <td>   -1.1428</td> <td>    0.130</td> <td>   -8.804</td> <td> 0.000</td> <td>   -1.397</td> <td>   -0.888</td>
</tr>
<tr>
  <th>Lead Origin_Lead Import</th>                              <td>    0.8679</td> <td>    0.477</td> <td>    1.820</td> <td> 0.069</td> <td>   -0.067</td> <td>    1.803</td>
</tr>
<tr>
  <th>Lead Source_Olark Chat</th>                               <td>    1.0968</td> <td>    0.124</td> <td>    8.830</td> <td> 0.000</td> <td>    0.853</td> <td>    1.340</td>
</tr>
<tr>
  <th>Lead Source_Reference</th>                                <td>    3.3310</td> <td>    0.243</td> <td>   13.683</td> <td> 0.000</td> <td>    2.854</td> <td>    3.808</td>
</tr>
<tr>
  <th>Lead Source_Welingak Website</th>                         <td>    5.8842</td> <td>    0.731</td> <td>    8.051</td> <td> 0.000</td> <td>    4.452</td> <td>    7.317</td>
</tr>
<tr>
  <th>Last Activity_Email Link Clicked</th>                     <td>    0.4563</td> <td>    0.397</td> <td>    1.150</td> <td> 0.250</td> <td>   -0.321</td> <td>    1.234</td>
</tr>
<tr>
  <th>Last Activity_Email Opened</th>                           <td>    0.6687</td> <td>    0.184</td> <td>    3.629</td> <td> 0.000</td> <td>    0.308</td> <td>    1.030</td>
</tr>
<tr>
  <th>Last Activity_Olark Chat Conversation</th>                <td>   -0.6135</td> <td>    0.226</td> <td>   -2.715</td> <td> 0.007</td> <td>   -1.057</td> <td>   -0.171</td>
</tr>
<tr>
  <th>Last Activity_Other_Activity</th>                         <td>    2.1694</td> <td>    0.595</td> <td>    3.646</td> <td> 0.000</td> <td>    1.003</td> <td>    3.336</td>
</tr>
<tr>
  <th>Last Activity_SMS Sent</th>                               <td>    1.1030</td> <td>    0.186</td> <td>    5.919</td> <td> 0.000</td> <td>    0.738</td> <td>    1.468</td>
</tr>
<tr>
  <th>Last Activity_Unreachable</th>                            <td>    0.2811</td> <td>    0.509</td> <td>    0.552</td> <td> 0.581</td> <td>   -0.716</td> <td>    1.279</td>
</tr>
<tr>
  <th>Last Activity_Unsubscribed</th>                           <td>    1.3749</td> <td>    1.124</td> <td>    1.223</td> <td> 0.221</td> <td>   -0.829</td> <td>    3.579</td>
</tr>
<tr>
  <th>Specialization_Hospitality Management</th>                <td>   -0.4343</td> <td>    0.329</td> <td>   -1.319</td> <td> 0.187</td> <td>   -1.080</td> <td>    0.211</td>
</tr>
<tr>
  <th>Specialization_Others</th>                                <td>   -1.1772</td> <td>    0.126</td> <td>   -9.306</td> <td> 0.000</td> <td>   -1.425</td> <td>   -0.929</td>
</tr>
<tr>
  <th>What is your current occupation_Working Professional</th> <td>    2.6054</td> <td>    0.196</td> <td>   13.301</td> <td> 0.000</td> <td>    2.222</td> <td>    2.989</td>
</tr>
<tr>
  <th>City_Tier II Cities</th>                                  <td>   -0.5801</td> <td>    0.455</td> <td>   -1.274</td> <td> 0.203</td> <td>   -1.472</td> <td>    0.312</td>
</tr>
<tr>
  <th>Last Notable Activity_Email Bounced</th>                  <td>   -0.6472</td> <td>    1.143</td> <td>   -0.566</td> <td> 0.571</td> <td>   -2.887</td> <td>    1.592</td>
</tr>
<tr>
  <th>Last Notable Activity_Email Link Clicked</th>             <td>   -1.8631</td> <td>    1.092</td> <td>   -1.706</td> <td> 0.088</td> <td>   -4.003</td> <td>    0.277</td>
</tr>
<tr>
  <th>Last Notable Activity_Email Opened</th>                   <td>   -1.6296</td> <td>    1.006</td> <td>   -1.621</td> <td> 0.105</td> <td>   -3.600</td> <td>    0.341</td>
</tr>
<tr>
  <th>Last Notable Activity_Modified</th>                       <td>   -2.0011</td> <td>    0.996</td> <td>   -2.009</td> <td> 0.045</td> <td>   -3.953</td> <td>   -0.049</td>
</tr>
<tr>
  <th>Last Notable Activity_Olark Chat Conversation</th>        <td>   -1.7205</td> <td>    1.061</td> <td>   -1.621</td> <td> 0.105</td> <td>   -3.800</td> <td>    0.359</td>
</tr>
<tr>
  <th>Last Notable Activity_Page Visited on Website</th>        <td>   -1.2288</td> <td>    1.019</td> <td>   -1.206</td> <td> 0.228</td> <td>   -3.226</td> <td>    0.768</td>
</tr>
<tr>
  <th>Last Notable Activity_SMS Sent</th>                       <td>   -0.6172</td> <td>    1.007</td> <td>   -0.613</td> <td> 0.540</td> <td>   -2.590</td> <td>    1.356</td>
</tr>
<tr>
  <th>Last Notable Activity_Unreachable</th>                    <td>    0.3204</td> <td>    1.207</td> <td>    0.266</td> <td> 0.791</td> <td>   -2.045</td> <td>    2.685</td>
</tr>
<tr>
  <th>Last Notable Activity_Unsubscribed</th>                   <td>   -0.9312</td> <td>    1.572</td> <td>   -0.592</td> <td> 0.554</td> <td>   -4.013</td> <td>    2.151</td>
</tr>
<tr>
  <th>Last Notable Activity_View in browser link Clicked</th>   <td>  -23.7736</td> <td> 2.92e+04</td> <td>   -0.001</td> <td> 0.999</td> <td>-5.73e+04</td> <td> 5.73e+04</td>
</tr>
</table>




```python
# Dropping the column  'Lead Origin_Lead Import' because it has high Pvalue
col1 = col1.drop('Lead Origin_Lead Import')
```

### Model-7


```python
X_train_sm = sm.add_constant(X_train[col1])
logm5 = sm.GLM(y_train,X_train_sm, family = sm.families.Binomial())
res = logm5.fit()
res.summary()
```




<table class="simpletable">
<caption>Generalized Linear Model Regression Results</caption>
<tr>
  <th>Dep. Variable:</th>       <td>Converted</td>    <th>  No. Observations:  </th>  <td>  6351</td> 
</tr>
<tr>
  <th>Model:</th>                  <td>GLM</td>       <th>  Df Residuals:      </th>  <td>  6322</td> 
</tr>
<tr>
  <th>Model Family:</th>        <td>Binomial</td>     <th>  Df Model:          </th>  <td>    28</td> 
</tr>
<tr>
  <th>Link Function:</th>         <td>Logit</td>      <th>  Scale:             </th> <td>  1.0000</td>
</tr>
<tr>
  <th>Method:</th>                <td>IRLS</td>       <th>  Log-Likelihood:    </th> <td> -2577.9</td>
</tr>
<tr>
  <th>Date:</th>            <td>Thu, 15 Jun 2023</td> <th>  Deviance:          </th> <td>  5155.9</td>
</tr>
<tr>
  <th>Time:</th>                <td>21:33:29</td>     <th>  Pearson chi2:      </th> <td>6.41e+03</td>
</tr>
<tr>
  <th>No. Iterations:</th>         <td>20</td>        <th>  Pseudo R-squ. (CS):</th>  <td>0.4062</td> 
</tr>
<tr>
  <th>Covariance Type:</th>     <td>nonrobust</td>    <th>                     </th>     <td> </td>   
</tr>
</table>
<table class="simpletable">
<tr>
                            <td></td>                              <th>coef</th>     <th>std err</th>      <th>z</th>      <th>P>|z|</th>  <th>[0.025</th>    <th>0.975]</th>  
</tr>
<tr>
  <th>const</th>                                                <td>    0.8740</td> <td>    1.006</td> <td>    0.869</td> <td> 0.385</td> <td>   -1.097</td> <td>    2.845</td>
</tr>
<tr>
  <th>Do Not Email</th>                                         <td>   -1.6515</td> <td>    0.210</td> <td>   -7.851</td> <td> 0.000</td> <td>   -2.064</td> <td>   -1.239</td>
</tr>
<tr>
  <th>Do Not Call</th>                                          <td>   20.5451</td> <td>    2e+04</td> <td>    0.001</td> <td> 0.999</td> <td>-3.92e+04</td> <td> 3.92e+04</td>
</tr>
<tr>
  <th>Total Time Spent on Website</th>                          <td>    1.1005</td> <td>    0.041</td> <td>   27.024</td> <td> 0.000</td> <td>    1.021</td> <td>    1.180</td>
</tr>
<tr>
  <th>Lead Origin_Landing Page Submission</th>                  <td>   -1.1782</td> <td>    0.129</td> <td>   -9.165</td> <td> 0.000</td> <td>   -1.430</td> <td>   -0.926</td>
</tr>
<tr>
  <th>Lead Source_Olark Chat</th>                               <td>    1.0709</td> <td>    0.123</td> <td>    8.694</td> <td> 0.000</td> <td>    0.830</td> <td>    1.312</td>
</tr>
<tr>
  <th>Lead Source_Reference</th>                                <td>    3.2964</td> <td>    0.243</td> <td>   13.585</td> <td> 0.000</td> <td>    2.821</td> <td>    3.772</td>
</tr>
<tr>
  <th>Lead Source_Welingak Website</th>                         <td>    5.8591</td> <td>    0.731</td> <td>    8.018</td> <td> 0.000</td> <td>    4.427</td> <td>    7.291</td>
</tr>
<tr>
  <th>Last Activity_Email Link Clicked</th>                     <td>    0.4562</td> <td>    0.396</td> <td>    1.151</td> <td> 0.250</td> <td>   -0.321</td> <td>    1.233</td>
</tr>
<tr>
  <th>Last Activity_Email Opened</th>                           <td>    0.6755</td> <td>    0.184</td> <td>    3.668</td> <td> 0.000</td> <td>    0.315</td> <td>    1.036</td>
</tr>
<tr>
  <th>Last Activity_Olark Chat Conversation</th>                <td>   -0.6144</td> <td>    0.226</td> <td>   -2.718</td> <td> 0.007</td> <td>   -1.057</td> <td>   -0.171</td>
</tr>
<tr>
  <th>Last Activity_Other_Activity</th>                         <td>    2.1682</td> <td>    0.594</td> <td>    3.649</td> <td> 0.000</td> <td>    1.004</td> <td>    3.333</td>
</tr>
<tr>
  <th>Last Activity_SMS Sent</th>                               <td>    1.1116</td> <td>    0.186</td> <td>    5.970</td> <td> 0.000</td> <td>    0.747</td> <td>    1.476</td>
</tr>
<tr>
  <th>Last Activity_Unreachable</th>                            <td>    0.2820</td> <td>    0.509</td> <td>    0.554</td> <td> 0.579</td> <td>   -0.715</td> <td>    1.279</td>
</tr>
<tr>
  <th>Last Activity_Unsubscribed</th>                           <td>    1.3738</td> <td>    1.123</td> <td>    1.223</td> <td> 0.221</td> <td>   -0.828</td> <td>    3.576</td>
</tr>
<tr>
  <th>Specialization_Hospitality Management</th>                <td>   -0.4369</td> <td>    0.329</td> <td>   -1.327</td> <td> 0.185</td> <td>   -1.082</td> <td>    0.208</td>
</tr>
<tr>
  <th>Specialization_Others</th>                                <td>   -1.1989</td> <td>    0.126</td> <td>   -9.492</td> <td> 0.000</td> <td>   -1.447</td> <td>   -0.951</td>
</tr>
<tr>
  <th>What is your current occupation_Working Professional</th> <td>    2.6058</td> <td>    0.196</td> <td>   13.308</td> <td> 0.000</td> <td>    2.222</td> <td>    2.990</td>
</tr>
<tr>
  <th>City_Tier II Cities</th>                                  <td>   -0.5781</td> <td>    0.454</td> <td>   -1.272</td> <td> 0.203</td> <td>   -1.469</td> <td>    0.313</td>
</tr>
<tr>
  <th>Last Notable Activity_Email Bounced</th>                  <td>   -0.6446</td> <td>    1.142</td> <td>   -0.564</td> <td> 0.573</td> <td>   -2.883</td> <td>    1.594</td>
</tr>
<tr>
  <th>Last Notable Activity_Email Link Clicked</th>             <td>   -1.8592</td> <td>    1.091</td> <td>   -1.704</td> <td> 0.088</td> <td>   -3.998</td> <td>    0.280</td>
</tr>
<tr>
  <th>Last Notable Activity_Email Opened</th>                   <td>   -1.6267</td> <td>    1.005</td> <td>   -1.618</td> <td> 0.106</td> <td>   -3.597</td> <td>    0.343</td>
</tr>
<tr>
  <th>Last Notable Activity_Modified</th>                       <td>   -1.9988</td> <td>    0.996</td> <td>   -2.008</td> <td> 0.045</td> <td>   -3.950</td> <td>   -0.048</td>
</tr>
<tr>
  <th>Last Notable Activity_Olark Chat Conversation</th>        <td>   -1.7126</td> <td>    1.061</td> <td>   -1.615</td> <td> 0.106</td> <td>   -3.792</td> <td>    0.366</td>
</tr>
<tr>
  <th>Last Notable Activity_Page Visited on Website</th>        <td>   -1.2268</td> <td>    1.018</td> <td>   -1.205</td> <td> 0.228</td> <td>   -3.223</td> <td>    0.769</td>
</tr>
<tr>
  <th>Last Notable Activity_SMS Sent</th>                       <td>   -0.6225</td> <td>    1.006</td> <td>   -0.619</td> <td> 0.536</td> <td>   -2.595</td> <td>    1.350</td>
</tr>
<tr>
  <th>Last Notable Activity_Unreachable</th>                    <td>    0.3169</td> <td>    1.206</td> <td>    0.263</td> <td> 0.793</td> <td>   -2.047</td> <td>    2.681</td>
</tr>
<tr>
  <th>Last Notable Activity_Unsubscribed</th>                   <td>   -0.9282</td> <td>    1.571</td> <td>   -0.591</td> <td> 0.555</td> <td>   -4.008</td> <td>    2.152</td>
</tr>
<tr>
  <th>Last Notable Activity_View in browser link Clicked</th>   <td>  -23.8100</td> <td> 2.92e+04</td> <td>   -0.001</td> <td> 0.999</td> <td>-5.73e+04</td> <td> 5.73e+04</td>
</tr>
</table>



### Checking for VIF values:


```python
# Check for the VIF values of the feature variables. 
from statsmodels.stats.outliers_influence import variance_inflation_factor

# Create a dataframe that will contain the names of all the feature variables and their respective VIFs
vif = pd.DataFrame()
vif['Features'] = X_train[col1].columns
vif['VIF'] = [variance_inflation_factor(X_train[col1].values, i) for i in range(X_train[col1].shape[1])]
vif['VIF'] = round(vif['VIF'], 2)
vif = vif.sort_values(by = "VIF", ascending = False)
vif
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Features</th>
      <th>VIF</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>20</th>
      <td>Last Notable Activity_Email Opened</td>
      <td>11.92</td>
    </tr>
    <tr>
      <th>24</th>
      <td>Last Notable Activity_SMS Sent</td>
      <td>9.94</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Last Activity_Email Opened</td>
      <td>9.20</td>
    </tr>
    <tr>
      <th>11</th>
      <td>Last Activity_SMS Sent</td>
      <td>7.60</td>
    </tr>
    <tr>
      <th>21</th>
      <td>Last Notable Activity_Modified</td>
      <td>7.52</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Lead Origin_Landing Page Submission</td>
      <td>7.15</td>
    </tr>
    <tr>
      <th>15</th>
      <td>Specialization_Others</td>
      <td>4.64</td>
    </tr>
    <tr>
      <th>26</th>
      <td>Last Notable Activity_Unsubscribed</td>
      <td>3.66</td>
    </tr>
    <tr>
      <th>13</th>
      <td>Last Activity_Unsubscribed</td>
      <td>3.62</td>
    </tr>
    <tr>
      <th>19</th>
      <td>Last Notable Activity_Email Link Clicked</td>
      <td>3.28</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Last Activity_Email Link Clicked</td>
      <td>3.18</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Last Activity_Olark Chat Conversation</td>
      <td>2.58</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Lead Source_Olark Chat</td>
      <td>2.32</td>
    </tr>
    <tr>
      <th>12</th>
      <td>Last Activity_Unreachable</td>
      <td>1.69</td>
    </tr>
    <tr>
      <th>25</th>
      <td>Last Notable Activity_Unreachable</td>
      <td>1.66</td>
    </tr>
    <tr>
      <th>22</th>
      <td>Last Notable Activity_Olark Chat Conversation</td>
      <td>1.64</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Lead Source_Reference</td>
      <td>1.56</td>
    </tr>
    <tr>
      <th>0</th>
      <td>Do Not Email</td>
      <td>1.47</td>
    </tr>
    <tr>
      <th>23</th>
      <td>Last Notable Activity_Page Visited on Website</td>
      <td>1.38</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Total Time Spent on Website</td>
      <td>1.33</td>
    </tr>
    <tr>
      <th>16</th>
      <td>What is your current occupation_Working Profes...</td>
      <td>1.24</td>
    </tr>
    <tr>
      <th>18</th>
      <td>Last Notable Activity_Email Bounced</td>
      <td>1.22</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Lead Source_Welingak Website</td>
      <td>1.11</td>
    </tr>
    <tr>
      <th>10</th>
      <td>Last Activity_Other_Activity</td>
      <td>1.06</td>
    </tr>
    <tr>
      <th>27</th>
      <td>Last Notable Activity_View in browser link Cli...</td>
      <td>1.03</td>
    </tr>
    <tr>
      <th>17</th>
      <td>City_Tier II Cities</td>
      <td>1.02</td>
    </tr>
    <tr>
      <th>14</th>
      <td>Specialization_Hospitality Management</td>
      <td>1.02</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Do Not Call</td>
      <td>1.01</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Dropping the column  'Last Activity_Unsubscribed' to reduce the variables
col1 = col1.drop('Last Activity_Unsubscribed')
```

### Model-8


```python
X_train_sm = sm.add_constant(X_train[col1])
logm5 = sm.GLM(y_train,X_train_sm, family = sm.families.Binomial())
res = logm5.fit()
res.summary()
```




<table class="simpletable">
<caption>Generalized Linear Model Regression Results</caption>
<tr>
  <th>Dep. Variable:</th>       <td>Converted</td>    <th>  No. Observations:  </th>  <td>  6351</td> 
</tr>
<tr>
  <th>Model:</th>                  <td>GLM</td>       <th>  Df Residuals:      </th>  <td>  6323</td> 
</tr>
<tr>
  <th>Model Family:</th>        <td>Binomial</td>     <th>  Df Model:          </th>  <td>    27</td> 
</tr>
<tr>
  <th>Link Function:</th>         <td>Logit</td>      <th>  Scale:             </th> <td>  1.0000</td>
</tr>
<tr>
  <th>Method:</th>                <td>IRLS</td>       <th>  Log-Likelihood:    </th> <td> -2578.5</td>
</tr>
<tr>
  <th>Date:</th>            <td>Thu, 15 Jun 2023</td> <th>  Deviance:          </th> <td>  5157.0</td>
</tr>
<tr>
  <th>Time:</th>                <td>21:33:50</td>     <th>  Pearson chi2:      </th> <td>6.42e+03</td>
</tr>
<tr>
  <th>No. Iterations:</th>         <td>20</td>        <th>  Pseudo R-squ. (CS):</th>  <td>0.4061</td> 
</tr>
<tr>
  <th>Covariance Type:</th>     <td>nonrobust</td>    <th>                     </th>     <td> </td>   
</tr>
</table>
<table class="simpletable">
<tr>
                            <td></td>                              <th>coef</th>     <th>std err</th>      <th>z</th>      <th>P>|z|</th>  <th>[0.025</th>    <th>0.975]</th>  
</tr>
<tr>
  <th>const</th>                                                <td>    0.8811</td> <td>    1.005</td> <td>    0.877</td> <td> 0.381</td> <td>   -1.089</td> <td>    2.851</td>
</tr>
<tr>
  <th>Do Not Email</th>                                         <td>   -1.6342</td> <td>    0.210</td> <td>   -7.799</td> <td> 0.000</td> <td>   -2.045</td> <td>   -1.223</td>
</tr>
<tr>
  <th>Do Not Call</th>                                          <td>   20.5460</td> <td>    2e+04</td> <td>    0.001</td> <td> 0.999</td> <td>-3.92e+04</td> <td> 3.92e+04</td>
</tr>
<tr>
  <th>Total Time Spent on Website</th>                          <td>    1.1000</td> <td>    0.041</td> <td>   27.016</td> <td> 0.000</td> <td>    1.020</td> <td>    1.180</td>
</tr>
<tr>
  <th>Lead Origin_Landing Page Submission</th>                  <td>   -1.1774</td> <td>    0.129</td> <td>   -9.162</td> <td> 0.000</td> <td>   -1.429</td> <td>   -0.926</td>
</tr>
<tr>
  <th>Lead Source_Olark Chat</th>                               <td>    1.0702</td> <td>    0.123</td> <td>    8.689</td> <td> 0.000</td> <td>    0.829</td> <td>    1.312</td>
</tr>
<tr>
  <th>Lead Source_Reference</th>                                <td>    3.2958</td> <td>    0.243</td> <td>   13.587</td> <td> 0.000</td> <td>    2.820</td> <td>    3.771</td>
</tr>
<tr>
  <th>Lead Source_Welingak Website</th>                         <td>    5.8554</td> <td>    0.731</td> <td>    8.015</td> <td> 0.000</td> <td>    4.424</td> <td>    7.287</td>
</tr>
<tr>
  <th>Last Activity_Email Link Clicked</th>                     <td>    0.4457</td> <td>    0.396</td> <td>    1.125</td> <td> 0.261</td> <td>   -0.331</td> <td>    1.222</td>
</tr>
<tr>
  <th>Last Activity_Email Opened</th>                           <td>    0.6650</td> <td>    0.184</td> <td>    3.620</td> <td> 0.000</td> <td>    0.305</td> <td>    1.025</td>
</tr>
<tr>
  <th>Last Activity_Olark Chat Conversation</th>                <td>   -0.6248</td> <td>    0.226</td> <td>   -2.770</td> <td> 0.006</td> <td>   -1.067</td> <td>   -0.183</td>
</tr>
<tr>
  <th>Last Activity_Other_Activity</th>                         <td>    2.1577</td> <td>    0.594</td> <td>    3.633</td> <td> 0.000</td> <td>    0.994</td> <td>    3.322</td>
</tr>
<tr>
  <th>Last Activity_SMS Sent</th>                               <td>    1.1000</td> <td>    0.186</td> <td>    5.925</td> <td> 0.000</td> <td>    0.736</td> <td>    1.464</td>
</tr>
<tr>
  <th>Last Activity_Unreachable</th>                            <td>    0.2704</td> <td>    0.508</td> <td>    0.532</td> <td> 0.595</td> <td>   -0.726</td> <td>    1.267</td>
</tr>
<tr>
  <th>Specialization_Hospitality Management</th>                <td>   -0.4375</td> <td>    0.329</td> <td>   -1.329</td> <td> 0.184</td> <td>   -1.082</td> <td>    0.207</td>
</tr>
<tr>
  <th>Specialization_Others</th>                                <td>   -1.1983</td> <td>    0.126</td> <td>   -9.491</td> <td> 0.000</td> <td>   -1.446</td> <td>   -0.951</td>
</tr>
<tr>
  <th>What is your current occupation_Working Professional</th> <td>    2.6042</td> <td>    0.196</td> <td>   13.309</td> <td> 0.000</td> <td>    2.221</td> <td>    2.988</td>
</tr>
<tr>
  <th>City_Tier II Cities</th>                                  <td>   -0.5809</td> <td>    0.454</td> <td>   -1.279</td> <td> 0.201</td> <td>   -1.471</td> <td>    0.309</td>
</tr>
<tr>
  <th>Last Notable Activity_Email Bounced</th>                  <td>   -0.6690</td> <td>    1.141</td> <td>   -0.586</td> <td> 0.558</td> <td>   -2.906</td> <td>    1.568</td>
</tr>
<tr>
  <th>Last Notable Activity_Email Link Clicked</th>             <td>   -1.8560</td> <td>    1.091</td> <td>   -1.702</td> <td> 0.089</td> <td>   -3.994</td> <td>    0.282</td>
</tr>
<tr>
  <th>Last Notable Activity_Email Opened</th>                   <td>   -1.6236</td> <td>    1.005</td> <td>   -1.616</td> <td> 0.106</td> <td>   -3.592</td> <td>    0.345</td>
</tr>
<tr>
  <th>Last Notable Activity_Modified</th>                       <td>   -1.9956</td> <td>    0.995</td> <td>   -2.006</td> <td> 0.045</td> <td>   -3.946</td> <td>   -0.046</td>
</tr>
<tr>
  <th>Last Notable Activity_Olark Chat Conversation</th>        <td>   -1.7096</td> <td>    1.060</td> <td>   -1.613</td> <td> 0.107</td> <td>   -3.787</td> <td>    0.368</td>
</tr>
<tr>
  <th>Last Notable Activity_Page Visited on Website</th>        <td>   -1.2351</td> <td>    1.018</td> <td>   -1.214</td> <td> 0.225</td> <td>   -3.230</td> <td>    0.760</td>
</tr>
<tr>
  <th>Last Notable Activity_SMS Sent</th>                       <td>   -0.6195</td> <td>    1.006</td> <td>   -0.616</td> <td> 0.538</td> <td>   -2.591</td> <td>    1.352</td>
</tr>
<tr>
  <th>Last Notable Activity_Unreachable</th>                    <td>    0.3204</td> <td>    1.206</td> <td>    0.266</td> <td> 0.790</td> <td>   -2.042</td> <td>    2.683</td>
</tr>
<tr>
  <th>Last Notable Activity_Unsubscribed</th>                   <td>    0.4210</td> <td>    1.129</td> <td>    0.373</td> <td> 0.709</td> <td>   -1.792</td> <td>    2.634</td>
</tr>
<tr>
  <th>Last Notable Activity_View in browser link Clicked</th>   <td>  -23.8070</td> <td> 2.92e+04</td> <td>   -0.001</td> <td> 0.999</td> <td>-5.73e+04</td> <td> 5.73e+04</td>
</tr>
</table>



### Checking for VIF values:


```python
# Check for the VIF values of the feature variables. 
from statsmodels.stats.outliers_influence import variance_inflation_factor

# Create a dataframe that will contain the names of all the feature variables and their respective VIFs
vif = pd.DataFrame()
vif['Features'] = X_train[col1].columns
vif['VIF'] = [variance_inflation_factor(X_train[col1].values, i) for i in range(X_train[col1].shape[1])]
vif['VIF'] = round(vif['VIF'], 2)
vif = vif.sort_values(by = "VIF", ascending = False)
vif
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Features</th>
      <th>VIF</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>19</th>
      <td>Last Notable Activity_Email Opened</td>
      <td>11.90</td>
    </tr>
    <tr>
      <th>23</th>
      <td>Last Notable Activity_SMS Sent</td>
      <td>9.92</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Last Activity_Email Opened</td>
      <td>9.18</td>
    </tr>
    <tr>
      <th>11</th>
      <td>Last Activity_SMS Sent</td>
      <td>7.58</td>
    </tr>
    <tr>
      <th>20</th>
      <td>Last Notable Activity_Modified</td>
      <td>7.50</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Lead Origin_Landing Page Submission</td>
      <td>7.15</td>
    </tr>
    <tr>
      <th>14</th>
      <td>Specialization_Others</td>
      <td>4.64</td>
    </tr>
    <tr>
      <th>18</th>
      <td>Last Notable Activity_Email Link Clicked</td>
      <td>3.28</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Last Activity_Email Link Clicked</td>
      <td>3.17</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Last Activity_Olark Chat Conversation</td>
      <td>2.58</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Lead Source_Olark Chat</td>
      <td>2.32</td>
    </tr>
    <tr>
      <th>12</th>
      <td>Last Activity_Unreachable</td>
      <td>1.69</td>
    </tr>
    <tr>
      <th>24</th>
      <td>Last Notable Activity_Unreachable</td>
      <td>1.66</td>
    </tr>
    <tr>
      <th>21</th>
      <td>Last Notable Activity_Olark Chat Conversation</td>
      <td>1.64</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Lead Source_Reference</td>
      <td>1.56</td>
    </tr>
    <tr>
      <th>0</th>
      <td>Do Not Email</td>
      <td>1.46</td>
    </tr>
    <tr>
      <th>22</th>
      <td>Last Notable Activity_Page Visited on Website</td>
      <td>1.38</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Total Time Spent on Website</td>
      <td>1.33</td>
    </tr>
    <tr>
      <th>15</th>
      <td>What is your current occupation_Working Profes...</td>
      <td>1.24</td>
    </tr>
    <tr>
      <th>17</th>
      <td>Last Notable Activity_Email Bounced</td>
      <td>1.22</td>
    </tr>
    <tr>
      <th>25</th>
      <td>Last Notable Activity_Unsubscribed</td>
      <td>1.13</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Lead Source_Welingak Website</td>
      <td>1.11</td>
    </tr>
    <tr>
      <th>10</th>
      <td>Last Activity_Other_Activity</td>
      <td>1.06</td>
    </tr>
    <tr>
      <th>26</th>
      <td>Last Notable Activity_View in browser link Cli...</td>
      <td>1.03</td>
    </tr>
    <tr>
      <th>16</th>
      <td>City_Tier II Cities</td>
      <td>1.02</td>
    </tr>
    <tr>
      <th>13</th>
      <td>Specialization_Hospitality Management</td>
      <td>1.02</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Do Not Call</td>
      <td>1.01</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Dropping the column  'Last Notable Activity_Unreachable' to reduce the variables
col1 = col1.drop('Last Notable Activity_Unreachable')
```

### Model-9


```python
X_train_sm = sm.add_constant(X_train[col1])
logm5 = sm.GLM(y_train,X_train_sm, family = sm.families.Binomial())
res = logm5.fit()
res.summary()
```




<table class="simpletable">
<caption>Generalized Linear Model Regression Results</caption>
<tr>
  <th>Dep. Variable:</th>       <td>Converted</td>    <th>  No. Observations:  </th>  <td>  6351</td> 
</tr>
<tr>
  <th>Model:</th>                  <td>GLM</td>       <th>  Df Residuals:      </th>  <td>  6324</td> 
</tr>
<tr>
  <th>Model Family:</th>        <td>Binomial</td>     <th>  Df Model:          </th>  <td>    26</td> 
</tr>
<tr>
  <th>Link Function:</th>         <td>Logit</td>      <th>  Scale:             </th> <td>  1.0000</td>
</tr>
<tr>
  <th>Method:</th>                <td>IRLS</td>       <th>  Log-Likelihood:    </th> <td> -2578.5</td>
</tr>
<tr>
  <th>Date:</th>            <td>Thu, 15 Jun 2023</td> <th>  Deviance:          </th> <td>  5157.1</td>
</tr>
<tr>
  <th>Time:</th>                <td>21:34:06</td>     <th>  Pearson chi2:      </th> <td>6.41e+03</td>
</tr>
<tr>
  <th>No. Iterations:</th>         <td>20</td>        <th>  Pseudo R-squ. (CS):</th>  <td>0.4061</td> 
</tr>
<tr>
  <th>Covariance Type:</th>     <td>nonrobust</td>    <th>                     </th>     <td> </td>   
</tr>
</table>
<table class="simpletable">
<tr>
                            <td></td>                              <th>coef</th>     <th>std err</th>      <th>z</th>      <th>P>|z|</th>  <th>[0.025</th>    <th>0.975]</th>  
</tr>
<tr>
  <th>const</th>                                                <td>    1.1007</td> <td>    0.584</td> <td>    1.885</td> <td> 0.059</td> <td>   -0.044</td> <td>    2.245</td>
</tr>
<tr>
  <th>Do Not Email</th>                                         <td>   -1.6344</td> <td>    0.210</td> <td>   -7.798</td> <td> 0.000</td> <td>   -2.045</td> <td>   -1.224</td>
</tr>
<tr>
  <th>Do Not Call</th>                                          <td>   20.5465</td> <td>    2e+04</td> <td>    0.001</td> <td> 0.999</td> <td>-3.92e+04</td> <td> 3.92e+04</td>
</tr>
<tr>
  <th>Total Time Spent on Website</th>                          <td>    1.1000</td> <td>    0.041</td> <td>   27.017</td> <td> 0.000</td> <td>    1.020</td> <td>    1.180</td>
</tr>
<tr>
  <th>Lead Origin_Landing Page Submission</th>                  <td>   -1.1778</td> <td>    0.129</td> <td>   -9.166</td> <td> 0.000</td> <td>   -1.430</td> <td>   -0.926</td>
</tr>
<tr>
  <th>Lead Source_Olark Chat</th>                               <td>    1.0701</td> <td>    0.123</td> <td>    8.688</td> <td> 0.000</td> <td>    0.829</td> <td>    1.311</td>
</tr>
<tr>
  <th>Lead Source_Reference</th>                                <td>    3.2950</td> <td>    0.243</td> <td>   13.585</td> <td> 0.000</td> <td>    2.820</td> <td>    3.770</td>
</tr>
<tr>
  <th>Lead Source_Welingak Website</th>                         <td>    5.8550</td> <td>    0.731</td> <td>    8.014</td> <td> 0.000</td> <td>    4.423</td> <td>    7.287</td>
</tr>
<tr>
  <th>Last Activity_Email Link Clicked</th>                     <td>    0.4465</td> <td>    0.396</td> <td>    1.127</td> <td> 0.260</td> <td>   -0.330</td> <td>    1.223</td>
</tr>
<tr>
  <th>Last Activity_Email Opened</th>                           <td>    0.6657</td> <td>    0.184</td> <td>    3.624</td> <td> 0.000</td> <td>    0.306</td> <td>    1.026</td>
</tr>
<tr>
  <th>Last Activity_Olark Chat Conversation</th>                <td>   -0.6244</td> <td>    0.226</td> <td>   -2.767</td> <td> 0.006</td> <td>   -1.067</td> <td>   -0.182</td>
</tr>
<tr>
  <th>Last Activity_Other_Activity</th>                         <td>    2.0983</td> <td>    0.550</td> <td>    3.815</td> <td> 0.000</td> <td>    1.020</td> <td>    3.176</td>
</tr>
<tr>
  <th>Last Activity_SMS Sent</th>                               <td>    1.1008</td> <td>    0.186</td> <td>    5.930</td> <td> 0.000</td> <td>    0.737</td> <td>    1.465</td>
</tr>
<tr>
  <th>Last Activity_Unreachable</th>                            <td>    0.3232</td> <td>    0.462</td> <td>    0.700</td> <td> 0.484</td> <td>   -0.582</td> <td>    1.228</td>
</tr>
<tr>
  <th>Specialization_Hospitality Management</th>                <td>   -0.4378</td> <td>    0.329</td> <td>   -1.331</td> <td> 0.183</td> <td>   -1.083</td> <td>    0.207</td>
</tr>
<tr>
  <th>Specialization_Others</th>                                <td>   -1.1978</td> <td>    0.126</td> <td>   -9.489</td> <td> 0.000</td> <td>   -1.445</td> <td>   -0.950</td>
</tr>
<tr>
  <th>What is your current occupation_Working Professional</th> <td>    2.6052</td> <td>    0.196</td> <td>   13.316</td> <td> 0.000</td> <td>    2.222</td> <td>    2.989</td>
</tr>
<tr>
  <th>City_Tier II Cities</th>                                  <td>   -0.5805</td> <td>    0.454</td> <td>   -1.279</td> <td> 0.201</td> <td>   -1.470</td> <td>    0.309</td>
</tr>
<tr>
  <th>Last Notable Activity_Email Bounced</th>                  <td>   -0.8884</td> <td>    0.797</td> <td>   -1.115</td> <td> 0.265</td> <td>   -2.451</td> <td>    0.674</td>
</tr>
<tr>
  <th>Last Notable Activity_Email Link Clicked</th>             <td>   -2.0765</td> <td>    0.718</td> <td>   -2.891</td> <td> 0.004</td> <td>   -3.484</td> <td>   -0.669</td>
</tr>
<tr>
  <th>Last Notable Activity_Email Opened</th>                   <td>   -1.8440</td> <td>    0.579</td> <td>   -3.183</td> <td> 0.001</td> <td>   -2.979</td> <td>   -0.709</td>
</tr>
<tr>
  <th>Last Notable Activity_Modified</th>                       <td>   -2.2160</td> <td>    0.562</td> <td>   -3.942</td> <td> 0.000</td> <td>   -3.318</td> <td>   -1.114</td>
</tr>
<tr>
  <th>Last Notable Activity_Olark Chat Conversation</th>        <td>   -1.9300</td> <td>    0.671</td> <td>   -2.876</td> <td> 0.004</td> <td>   -3.245</td> <td>   -0.615</td>
</tr>
<tr>
  <th>Last Notable Activity_Page Visited on Website</th>        <td>   -1.4547</td> <td>    0.606</td> <td>   -2.402</td> <td> 0.016</td> <td>   -2.642</td> <td>   -0.268</td>
</tr>
<tr>
  <th>Last Notable Activity_SMS Sent</th>                       <td>   -0.8400</td> <td>    0.581</td> <td>   -1.445</td> <td> 0.148</td> <td>   -1.979</td> <td>    0.299</td>
</tr>
<tr>
  <th>Last Notable Activity_Unsubscribed</th>                   <td>    0.2017</td> <td>    0.779</td> <td>    0.259</td> <td> 0.796</td> <td>   -1.325</td> <td>    1.729</td>
</tr>
<tr>
  <th>Last Notable Activity_View in browser link Clicked</th>   <td>  -23.9672</td> <td> 2.92e+04</td> <td>   -0.001</td> <td> 0.999</td> <td>-5.73e+04</td> <td> 5.73e+04</td>
</tr>
</table>



### Checking for VIF values:


```python
# Check for the VIF values of the feature variables. 
from statsmodels.stats.outliers_influence import variance_inflation_factor

# Create a dataframe that will contain the names of all the feature variables and their respective VIFs
vif = pd.DataFrame()
vif['Features'] = X_train[col1].columns
vif['VIF'] = [variance_inflation_factor(X_train[col1].values, i) for i in range(X_train[col1].shape[1])]
vif['VIF'] = round(vif['VIF'], 2)
vif = vif.sort_values(by = "VIF", ascending = False)
vif
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Features</th>
      <th>VIF</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>19</th>
      <td>Last Notable Activity_Email Opened</td>
      <td>11.63</td>
    </tr>
    <tr>
      <th>23</th>
      <td>Last Notable Activity_SMS Sent</td>
      <td>9.70</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Last Activity_Email Opened</td>
      <td>9.10</td>
    </tr>
    <tr>
      <th>11</th>
      <td>Last Activity_SMS Sent</td>
      <td>7.52</td>
    </tr>
    <tr>
      <th>20</th>
      <td>Last Notable Activity_Modified</td>
      <td>7.18</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Lead Origin_Landing Page Submission</td>
      <td>7.01</td>
    </tr>
    <tr>
      <th>14</th>
      <td>Specialization_Others</td>
      <td>4.57</td>
    </tr>
    <tr>
      <th>18</th>
      <td>Last Notable Activity_Email Link Clicked</td>
      <td>3.26</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Last Activity_Email Link Clicked</td>
      <td>3.17</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Last Activity_Olark Chat Conversation</td>
      <td>2.56</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Lead Source_Olark Chat</td>
      <td>2.32</td>
    </tr>
    <tr>
      <th>21</th>
      <td>Last Notable Activity_Olark Chat Conversation</td>
      <td>1.63</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Lead Source_Reference</td>
      <td>1.55</td>
    </tr>
    <tr>
      <th>0</th>
      <td>Do Not Email</td>
      <td>1.45</td>
    </tr>
    <tr>
      <th>22</th>
      <td>Last Notable Activity_Page Visited on Website</td>
      <td>1.37</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Total Time Spent on Website</td>
      <td>1.33</td>
    </tr>
    <tr>
      <th>15</th>
      <td>What is your current occupation_Working Profes...</td>
      <td>1.24</td>
    </tr>
    <tr>
      <th>17</th>
      <td>Last Notable Activity_Email Bounced</td>
      <td>1.22</td>
    </tr>
    <tr>
      <th>24</th>
      <td>Last Notable Activity_Unsubscribed</td>
      <td>1.12</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Lead Source_Welingak Website</td>
      <td>1.11</td>
    </tr>
    <tr>
      <th>10</th>
      <td>Last Activity_Other_Activity</td>
      <td>1.06</td>
    </tr>
    <tr>
      <th>12</th>
      <td>Last Activity_Unreachable</td>
      <td>1.05</td>
    </tr>
    <tr>
      <th>25</th>
      <td>Last Notable Activity_View in browser link Cli...</td>
      <td>1.03</td>
    </tr>
    <tr>
      <th>16</th>
      <td>City_Tier II Cities</td>
      <td>1.02</td>
    </tr>
    <tr>
      <th>13</th>
      <td>Specialization_Hospitality Management</td>
      <td>1.02</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Do Not Call</td>
      <td>1.01</td>
    </tr>
  </tbody>
</table>
</div>



**Since the Pvalues of all variables is 0 and VIF values are low for all the variables, model-9 is our final model. We have 12 variables in our final model.**

### Making Prediction on the Train set


```python
# Getting the predicted values on the train set
y_train_pred = res.predict(X_train_sm)
y_train_pred[:10]
```




    3009    0.192847
    1012    0.143494
    9226    0.246066
    4750    0.879901
    7987    0.736362
    1281    0.767144
    2880    0.097546
    4971    0.969406
    7536    0.853118
    1248    0.700893
    dtype: float64




```python
# Reshaping into an array
y_train_pred = y_train_pred.values.reshape(-1)
y_train_pred[:10]
```




    array([0.19284704, 0.14349358, 0.24606636, 0.87990051, 0.73636177,
           0.76714395, 0.09754585, 0.96940579, 0.85311778, 0.7008931 ])



**Creating a dataframe with the actual Converted flag and the predicted probabilities**


```python
y_train_pred_final = pd.DataFrame({'Converted':y_train.values, 'Converted_prob':y_train_pred})
y_train_pred_final['Prospect ID'] = y_train.index
y_train_pred_final.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Converted</th>
      <th>Converted_prob</th>
      <th>Prospect ID</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>0.192847</td>
      <td>3009</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0</td>
      <td>0.143494</td>
      <td>1012</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0</td>
      <td>0.246066</td>
      <td>9226</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1</td>
      <td>0.879901</td>
      <td>4750</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1</td>
      <td>0.736362</td>
      <td>7987</td>
    </tr>
  </tbody>
</table>
</div>



### Choosing an arbitrary cut-off probability point of 0.5 to find the predicted labels 

**Creating new column 'predicted' with 1 if Converted_Prob > 0.5 else 0**


```python
y_train_pred_final['predicted'] = y_train_pred_final.Converted_prob.map(lambda x: 1 if x > 0.5 else 0)

# Let's see the head
y_train_pred_final.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Converted</th>
      <th>Converted_prob</th>
      <th>Prospect ID</th>
      <th>predicted</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>0.192847</td>
      <td>3009</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0</td>
      <td>0.143494</td>
      <td>1012</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0</td>
      <td>0.246066</td>
      <td>9226</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1</td>
      <td>0.879901</td>
      <td>4750</td>
      <td>1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1</td>
      <td>0.736362</td>
      <td>7987</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>



### Making the Confusion matrix


```python
from sklearn import metrics

# Confusion matrix 
confusion = metrics.confusion_matrix(y_train_pred_final.Converted, y_train_pred_final.predicted )
print(confusion)
```

    [[3455  450]
     [ 705 1741]]
    


```python
# The confusion matrix indicates as below
# Predicted     not_converted    converted
# Actual
# not_converted        3461      444
# converted            719       1727  
```


```python
# Let's check the overall accuracy.
print('Accuracy :',metrics.accuracy_score(y_train_pred_final.Converted, y_train_pred_final.predicted))
```

    Accuracy : 0.8181388757675957
    

### Metrics beyond simply accuracy


```python
TP = confusion[1,1] # true positive 
TN = confusion[0,0] # true negatives
FP = confusion[0,1] # false positives
FN = confusion[1,0] # false negatives
```


```python
# Sensitivity of our logistic regression model
print("Sensitivity : ",TP / float(TP+FN))
```

    Sensitivity :  0.7117743254292723
    


```python
# Let us calculate specificity
print("Specificity : ",TN / float(TN+FP))
```

    Specificity :  0.8847631241997439
    


```python
# Calculate false postive rate - predicting converted lead when the lead actually was not converted
print("False Positive Rate :",FP/ float(TN+FP))
```

    False Positive Rate : 0.11523687580025609
    


```python
# positive predictive value 
print("Positive Predictive Value :",TP / float(TP+FP))
```

    Positive Predictive Value : 0.7946143313555454
    


```python
# Negative predictive value
print ("Negative predictive value :",TN / float(TN+ FN))
```

    Negative predictive value : 0.8305288461538461
    

#### We found out that our specificity was good (~88%) but our sensitivity was only 70%. Hence, this needed to be taken care of.
#### We have got sensitivity of 70% and this was mainly because of the cut-off point of 0.5 that we had arbitrarily chosen. Now, this cut-off point had to be optimised in order to get a decent value of sensitivity and for this we will use the ROC curve.

## Plotting the ROC Curve

An ROC curve demonstrates several things:

* It shows the tradeoff between sensitivity and specificity (any increase in sensitivity will be accompanied by a decrease in specificity).
* The closer the curve follows the left-hand border and then the top border of the ROC space, the more accurate the test.
* The closer the curve comes to the 45-degree diagonal of the ROC space, the less accurate the test.


```python
def draw_roc( actual, probs ):
    fpr, tpr, thresholds = metrics.roc_curve( actual, probs,
                                              drop_intermediate = False )
    auc_score = metrics.roc_auc_score( actual, probs )
    plt.figure(figsize=(5, 5))
    plt.plot( fpr, tpr, label='ROC curve (area = %0.2f)' % auc_score )
    plt.plot([0, 1], [0, 1], 'k--')
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.xlabel('False Positive Rate or [1 - True Negative Rate]')
    plt.ylabel('True Positive Rate')
    plt.title('Receiver operating characteristic example')
    plt.legend(loc="lower right")
    plt.show()

    return None
```


```python
fpr, tpr, thresholds = metrics.roc_curve( y_train_pred_final.Converted, y_train_pred_final.Converted_prob, drop_intermediate = False )
```


```python
draw_roc(y_train_pred_final.Converted, y_train_pred_final.Converted_prob)
```


    
![png](output_241_0.png)
    


**Since we have higher (0.89) area under the ROC curve , therefore our model is a good one.**

### Finding Optimal Cutoff Point

**Above we had chosen an arbitrary cut-off value of 0.5. We need to determine the best cut-off value and the below section deals with that. Optimal cutoff probability is that prob where we get balanced sensitivity and specificity**



```python
# Let's create columns with different probability cutoffs 
numbers = [float(x)/10 for x in range(10)]
for i in numbers:
    y_train_pred_final[i]= y_train_pred_final.Converted_prob.map(lambda x: 1 if x > i else 0)
y_train_pred_final.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Converted</th>
      <th>Converted_prob</th>
      <th>Prospect ID</th>
      <th>predicted</th>
      <th>0.0</th>
      <th>0.1</th>
      <th>0.2</th>
      <th>0.3</th>
      <th>0.4</th>
      <th>0.5</th>
      <th>0.6</th>
      <th>0.7</th>
      <th>0.8</th>
      <th>0.9</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>0.192847</td>
      <td>3009</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0</td>
      <td>0.143494</td>
      <td>1012</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0</td>
      <td>0.246066</td>
      <td>9226</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1</td>
      <td>0.879901</td>
      <td>4750</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1</td>
      <td>0.736362</td>
      <td>7987</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Now let's calculate accuracy sensitivity and specificity for various probability cutoffs.
cutoff_df = pd.DataFrame( columns = ['prob','accuracy','sensi','speci'])
from sklearn.metrics import confusion_matrix

# TP = confusion[1,1] # true positive 
# TN = confusion[0,0] # true negatives
# FP = confusion[0,1] # false positives
# FN = confusion[1,0] # false negatives

num = [0.0,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9]
for i in num:
    cm1 = metrics.confusion_matrix(y_train_pred_final.Converted, y_train_pred_final[i] )
    total1=sum(sum(cm1))
    accuracy = (cm1[0,0]+cm1[1,1])/total1
    
    speci = cm1[0,0]/(cm1[0,0]+cm1[0,1])
    sensi = cm1[1,1]/(cm1[1,0]+cm1[1,1])
    cutoff_df.loc[i] =[ i ,accuracy,sensi,speci]
print(cutoff_df)
```

         prob  accuracy     sensi     speci
    0.0   0.0  0.385136  1.000000  0.000000
    0.1   0.1  0.602110  0.973017  0.369782
    0.2   0.2  0.759408  0.913737  0.662740
    0.3   0.3  0.805857  0.850368  0.777977
    0.4   0.4  0.814675  0.781276  0.835595
    0.5   0.5  0.818139  0.711774  0.884763
    0.6   0.6  0.802393  0.606705  0.924968
    0.7   0.7  0.787278  0.529845  0.948528
    0.8   0.8  0.767123  0.441946  0.970807
    0.9   0.9  0.726500  0.309894  0.987452
    


```python
# Let's plot accuracy sensitivity and specificity for various probabilities.
cutoff_df.plot.line(x='prob', y=['accuracy','sensi','speci'])
plt.show()
```


    
![png](output_245_0.png)
    


#### From the curve above, 0.34 is the optimum point to take it as a cutoff probability.


```python
y_train_pred_final['final_predicted'] = y_train_pred_final.Converted_prob.map( lambda x: 1 if x > 0.34 else 0)

y_train_pred_final.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Converted</th>
      <th>Converted_prob</th>
      <th>Prospect ID</th>
      <th>predicted</th>
      <th>0.0</th>
      <th>0.1</th>
      <th>0.2</th>
      <th>0.3</th>
      <th>0.4</th>
      <th>0.5</th>
      <th>0.6</th>
      <th>0.7</th>
      <th>0.8</th>
      <th>0.9</th>
      <th>final_predicted</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>0.192847</td>
      <td>3009</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0</td>
      <td>0.143494</td>
      <td>1012</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0</td>
      <td>0.246066</td>
      <td>9226</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1</td>
      <td>0.879901</td>
      <td>4750</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1</td>
      <td>0.736362</td>
      <td>7987</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>



### Assigning Lead Score to the Training data



```python
y_train_pred_final['Lead_Score'] = y_train_pred_final.Converted_prob.map( lambda x: round(x*100))

y_train_pred_final.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Converted</th>
      <th>Converted_prob</th>
      <th>Prospect ID</th>
      <th>predicted</th>
      <th>0.0</th>
      <th>0.1</th>
      <th>0.2</th>
      <th>0.3</th>
      <th>0.4</th>
      <th>0.5</th>
      <th>0.6</th>
      <th>0.7</th>
      <th>0.8</th>
      <th>0.9</th>
      <th>final_predicted</th>
      <th>Lead_Score</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>0.192847</td>
      <td>3009</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>19</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0</td>
      <td>0.143494</td>
      <td>1012</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>14</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0</td>
      <td>0.246066</td>
      <td>9226</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>25</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1</td>
      <td>0.879901</td>
      <td>4750</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>88</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1</td>
      <td>0.736362</td>
      <td>7987</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>74</td>
    </tr>
  </tbody>
</table>
</div>



## Model Evaluation 


```python
# Let's check the overall accuracy.
print("Accuracy :",metrics.accuracy_score(y_train_pred_final.Converted, y_train_pred_final.final_predicted))
```

    Accuracy : 0.8110533774208786
    


```python
# Confusion matrix
confusion2 = metrics.confusion_matrix(y_train_pred_final.Converted, y_train_pred_final.final_predicted )
confusion2
```




    array([[3132,  773],
           [ 427, 2019]], dtype=int64)




```python
TP = confusion2[1,1] # true positive 
TN = confusion2[0,0] # true negatives
FP = confusion2[0,1] # false positives
FN = confusion2[1,0] # false negatives
```


```python
# Let's see the sensitivity of our logistic regression model
print("Sensitivity : ",TP / float(TP+FN))
```

    Sensitivity :  0.8254292722812756
    


```python
# Let us calculate specificity
print("Specificity :",TN / float(TN+FP))
```

    Specificity : 0.8020486555697823
    


```python
# Calculate false postive rate - predicting converted lead when the lead was actually not have converted
print("False Positive rate : ",FP/ float(TN+FP))
```

    False Positive rate :  0.19795134443021767
    


```python
# Positive predictive value 
print("Positive Predictive Value :",TP / float(TP+FP))
```

    Positive Predictive Value : 0.7231375358166189
    


```python
# Negative predictive value
print("Negative Predictive Value : ",TN / float(TN+ FN))
```

    Negative Predictive Value :  0.8800224782242203
    

## Precision and Recall

* **Precision = Also known as Positive Predictive Value, it refers to the percentage of the results which are relevant.**
* **Recall = Also known as Sensitivity , it refers to the percentage of total relevant results correctly classified by the algorithm.**


```python
#Looking at the confusion matrix again

confusion = metrics.confusion_matrix(y_train_pred_final.Converted, y_train_pred_final.predicted )
confusion
```




    array([[3455,  450],
           [ 705, 1741]], dtype=int64)




```python
# Precision
TP / TP + FP

print("Precision : ",confusion[1,1]/(confusion[0,1]+confusion[1,1]))
```

    Precision :  0.7946143313555454
    


```python
# Recall
TP / TP + FN

print("Recall :",confusion[1,1]/(confusion[1,0]+confusion[1,1]))
```

    Recall : 0.7117743254292723
    

Using sklearn utilities for the same


```python
from sklearn.metrics import precision_score, recall_score
```


```python
print("Precision :",precision_score(y_train_pred_final.Converted , y_train_pred_final.predicted))
```

    Precision : 0.7946143313555454
    


```python
print("Recall :",recall_score(y_train_pred_final.Converted, y_train_pred_final.predicted))
```

    Recall : 0.7117743254292723
    

### Precision and recall tradeoff¶


```python
from sklearn.metrics import precision_recall_curve

y_train_pred_final.Converted, y_train_pred_final.predicted
```




    (0       0
     1       0
     2       0
     3       1
     4       1
            ..
     6346    0
     6347    1
     6348    0
     6349    0
     6350    0
     Name: Converted, Length: 6351, dtype: int64,
     0       0
     1       0
     2       0
     3       1
     4       1
            ..
     6346    0
     6347    1
     6348    1
     6349    0
     6350    0
     Name: predicted, Length: 6351, dtype: int64)




```python
p, r, thresholds = precision_recall_curve(y_train_pred_final.Converted, y_train_pred_final.Converted_prob)
```


```python
# plotting a trade-off curve between precision and recall
plt.plot(thresholds, p[:-1], "g-")
plt.plot(thresholds, r[:-1], "r-")
plt.show()
```


    
![png](output_271_0.png)
    


**The above graph shows the trade-off between the Precision and Recall .

## Making predictions on the test set

### Scaling the test data


```python
X_test[['TotalVisits','Total Time Spent on Website','Page Views Per Visit']] = scaler.transform(X_test[['TotalVisits',
                                                                                                        'Total Time Spent on Website',
                                                                                                        'Page Views Per Visit']])
```


```python
# Assigning the columns selected by the final model to the X_test 
X_test = X_test[col1]
X_test.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Do Not Email</th>
      <th>Do Not Call</th>
      <th>Total Time Spent on Website</th>
      <th>Lead Origin_Landing Page Submission</th>
      <th>Lead Source_Olark Chat</th>
      <th>Lead Source_Reference</th>
      <th>Lead Source_Welingak Website</th>
      <th>Last Activity_Email Link Clicked</th>
      <th>Last Activity_Email Opened</th>
      <th>Last Activity_Olark Chat Conversation</th>
      <th>...</th>
      <th>City_Tier II Cities</th>
      <th>Last Notable Activity_Email Bounced</th>
      <th>Last Notable Activity_Email Link Clicked</th>
      <th>Last Notable Activity_Email Opened</th>
      <th>Last Notable Activity_Modified</th>
      <th>Last Notable Activity_Olark Chat Conversation</th>
      <th>Last Notable Activity_Page Visited on Website</th>
      <th>Last Notable Activity_SMS Sent</th>
      <th>Last Notable Activity_Unsubscribed</th>
      <th>Last Notable Activity_View in browser link Clicked</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>3271</th>
      <td>0</td>
      <td>0</td>
      <td>-0.600595</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1490</th>
      <td>0</td>
      <td>0</td>
      <td>1.887326</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>7936</th>
      <td>0</td>
      <td>0</td>
      <td>-0.752879</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4216</th>
      <td>0</td>
      <td>0</td>
      <td>-0.888650</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3830</th>
      <td>0</td>
      <td>0</td>
      <td>-0.587751</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 26 columns</p>
</div>




```python
# Adding a const
X_test_sm = sm.add_constant(X_test)

# Making predictions on the test set
y_test_pred = res.predict(X_test_sm)
y_test_pred[:10]
```




    3271    0.126088
    1490    0.968507
    7936    0.108756
    4216    0.866217
    3830    0.129897
    1800    0.628486
    6507    0.369732
    4821    0.298090
    4223    0.922821
    4714    0.246066
    dtype: float64




```python
# Converting y_test_pred to a dataframe which is an array
y_pred_1 = pd.DataFrame(y_test_pred)
```


```python
# Let's see the head
y_pred_1.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>0</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>3271</th>
      <td>0.126088</td>
    </tr>
    <tr>
      <th>1490</th>
      <td>0.968507</td>
    </tr>
    <tr>
      <th>7936</th>
      <td>0.108756</td>
    </tr>
    <tr>
      <th>4216</th>
      <td>0.866217</td>
    </tr>
    <tr>
      <th>3830</th>
      <td>0.129897</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Converting y_test to dataframe
y_test_df = pd.DataFrame(y_test)
```


```python
# Putting Prospect ID to index
y_test_df['Prospect ID'] = y_test_df.index
```


```python
# Removing index for both dataframes to append them side by side 
y_pred_1.reset_index(drop=True, inplace=True)
y_test_df.reset_index(drop=True, inplace=True)
```


```python
# Appending y_test_df and y_pred_1
y_pred_final = pd.concat([y_test_df, y_pred_1],axis=1)
```


```python
y_pred_final.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Converted</th>
      <th>Prospect ID</th>
      <th>0</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>3271</td>
      <td>0.126088</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>1490</td>
      <td>0.968507</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0</td>
      <td>7936</td>
      <td>0.108756</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1</td>
      <td>4216</td>
      <td>0.866217</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0</td>
      <td>3830</td>
      <td>0.129897</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Renaming the column 
y_pred_final= y_pred_final.rename(columns={ 0 : 'Converted_prob'})
```


```python
# Rearranging the columns
y_pred_final = y_pred_final.reindex(columns=['Prospect ID','Converted','Converted_prob'])
```


```python
# Let's see the head of y_pred_final
y_pred_final.head()

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Prospect ID</th>
      <th>Converted</th>
      <th>Converted_prob</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>3271</td>
      <td>0</td>
      <td>0.126088</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1490</td>
      <td>1</td>
      <td>0.968507</td>
    </tr>
    <tr>
      <th>2</th>
      <td>7936</td>
      <td>0</td>
      <td>0.108756</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4216</td>
      <td>1</td>
      <td>0.866217</td>
    </tr>
    <tr>
      <th>4</th>
      <td>3830</td>
      <td>0</td>
      <td>0.129897</td>
    </tr>
  </tbody>
</table>
</div>




```python
y_pred_final['final_predicted'] = y_pred_final.Converted_prob.map(lambda x: 1 if x > 0.34 else 0)
```


```python
y_pred_final.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Prospect ID</th>
      <th>Converted</th>
      <th>Converted_prob</th>
      <th>final_predicted</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>3271</td>
      <td>0</td>
      <td>0.126088</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1490</td>
      <td>1</td>
      <td>0.968507</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>7936</td>
      <td>0</td>
      <td>0.108756</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4216</td>
      <td>1</td>
      <td>0.866217</td>
      <td>1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>3830</td>
      <td>0</td>
      <td>0.129897</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Let's check the overall accuracy.
print("Accuracy :",metrics.accuracy_score(y_pred_final.Converted, y_pred_final.final_predicted))
```

    Accuracy : 0.8016893132574366
    


```python
# Making the confusion matrix
confusion2 = metrics.confusion_matrix(y_pred_final.Converted, y_pred_final.final_predicted )
confusion2
```




    array([[1385,  349],
           [ 191,  798]], dtype=int64)




```python
TP = confusion2[1,1] # true positive 
TN = confusion2[0,0] # true negatives
FP = confusion2[0,1] # false positives
FN = confusion2[1,0] # false negatives
```


```python
# Let's see the sensitivity of our logistic regression model
print("Sensitivity :",TP / float(TP+FN))
```

    Sensitivity : 0.8068756319514662
    


```python
# Let us calculate specificity
print("Specificity :",TN / float(TN+FP))
```

    Specificity : 0.7987312572087658
    

### Assigning Lead Score to the Testing data


```python
y_pred_final['Lead_Score'] = y_pred_final.Converted_prob.map( lambda x: round(x*100))

y_pred_final.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Prospect ID</th>
      <th>Converted</th>
      <th>Converted_prob</th>
      <th>final_predicted</th>
      <th>Lead_Score</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>3271</td>
      <td>0</td>
      <td>0.126088</td>
      <td>0</td>
      <td>13</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1490</td>
      <td>1</td>
      <td>0.968507</td>
      <td>1</td>
      <td>97</td>
    </tr>
    <tr>
      <th>2</th>
      <td>7936</td>
      <td>0</td>
      <td>0.108756</td>
      <td>0</td>
      <td>11</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4216</td>
      <td>1</td>
      <td>0.866217</td>
      <td>1</td>
      <td>87</td>
    </tr>
    <tr>
      <th>4</th>
      <td>3830</td>
      <td>0</td>
      <td>0.129897</td>
      <td>0</td>
      <td>13</td>
    </tr>
  </tbody>
</table>
</div>



## Observations:
After running the model on the Test Data , we obtain:

* **Accuracy : 80.4 %**
* **Sensitivity : 80.4 %**
* **Specificity : 80.5 %**

## Results :

### 1) Comparing the values obtained for Train & Test:

#### Train Data: 

* **Accuracy : 81.0 %**
* **Sensitivity : 81.7 %**
* **Specificity : 80.6 %**

#### Test Data: 

* **Accuracy : 80.4 %**
* **Sensitivity : 80.4 %**
* **Specificity : 80.5 %**

**Thus we have achieved our goal of getting a ballpark of the target lead conversion rate to be around 80% . The Model seems to predict the Conversion Rate very well and we should be able to give the CEO confidence in making good calls based on this model to get a higher lead conversion rate of 80%.**

### 2) Finding out the leads which should be contacted:
#### The customers which should be contacted are the customers whose "Lead Score" is equal to or greater than 85. They can be termed as 'Hot Leads'.


```python
hot_leads=y_pred_final.loc[y_pred_final["Lead_Score"]>=85]
hot_leads
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Prospect ID</th>
      <th>Converted</th>
      <th>Converted_prob</th>
      <th>final_predicted</th>
      <th>Lead_Score</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>1490</td>
      <td>1</td>
      <td>0.968507</td>
      <td>1</td>
      <td>97</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4216</td>
      <td>1</td>
      <td>0.866217</td>
      <td>1</td>
      <td>87</td>
    </tr>
    <tr>
      <th>8</th>
      <td>4223</td>
      <td>1</td>
      <td>0.922821</td>
      <td>1</td>
      <td>92</td>
    </tr>
    <tr>
      <th>16</th>
      <td>1946</td>
      <td>1</td>
      <td>0.930766</td>
      <td>1</td>
      <td>93</td>
    </tr>
    <tr>
      <th>21</th>
      <td>2461</td>
      <td>1</td>
      <td>0.993576</td>
      <td>1</td>
      <td>99</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>2694</th>
      <td>1566</td>
      <td>1</td>
      <td>0.946698</td>
      <td>1</td>
      <td>95</td>
    </tr>
    <tr>
      <th>2699</th>
      <td>6461</td>
      <td>1</td>
      <td>0.965536</td>
      <td>1</td>
      <td>97</td>
    </tr>
    <tr>
      <th>2703</th>
      <td>5741</td>
      <td>1</td>
      <td>0.918594</td>
      <td>1</td>
      <td>92</td>
    </tr>
    <tr>
      <th>2715</th>
      <td>6299</td>
      <td>1</td>
      <td>0.884533</td>
      <td>1</td>
      <td>88</td>
    </tr>
    <tr>
      <th>2720</th>
      <td>6501</td>
      <td>1</td>
      <td>0.869967</td>
      <td>1</td>
      <td>87</td>
    </tr>
  </tbody>
</table>
<p>379 rows × 5 columns</p>
</div>



**So there are 368 leads which can be contacted and have a high chance of getting converted.  The Prospect ID of the customers to be contacted are :**


```python
print("The Prospect ID of the customers which should be contacted are :")

hot_leads_ids = hot_leads["Prospect ID"].values.reshape(-1)
hot_leads_ids
```

    The Prospect ID of the customers which should be contacted are :
    




    array([1490, 4216, 4223, 1946, 2461, 5822, 2684, 2010, 4062, 7696, 9049,
           1518, 4543, 4830, 4365, 3542, 2504, 7674, 8596, 4003, 4963, 6947,
           4807,  446, 8372, 5805, 3758, 1561,  737, 9034, 6423, 8286, 7174,
           4461, 1436, 7552, 3932, 4080, 1475, 5785, 2860, 7253, 4297, 5490,
           1995, 6532, 4498, 5797, 8687,  831, 7653, 4149, 2018, 6743, 3307,
           3976, 5769, 1051, 1663, 3288, 8959, 7521, 8282, 8213, 9063, 5292,
           6913, 6015, 1481,  785, 3265, 3285, 7433, 3858, 3810, 2009, 8106,
            373, 3055, 7417, 4179, 8568, 7268, 4353, 6784, 6754, 7236, 2960,
           7753, 3983,  802, 8745, 4717,  505, 8509, 6094, 4992, 7036, 2680,
           7065,  112, 6149, 7157, 3827, 7175, 1675, 6999, 5826, 8492, 6499,
           2481, 3439, 4612, 7129, 4793, 1557, 4837, 2495,  822, 2378, 5090,
           5075, 7699, 5638, 2342, 8077, 2727,  720, 7489, 2961, 1542, 5656,
           2630, 6728, 8205, 6332, 8461, 2427, 5087,  174, 2674, 8065, 2095,
           1568, 8597, 4865, 3535, 4708, 1304, 6066, 6538, 5700, 1388, 5815,
           7970, 7902, 5804, 7805, 5042, 4081, 6684, 5440, 1927, 5032, 5824,
             64, 2650, 5808, 4578, 4803, 1470, 5810, 2473, 2584, 7259, 3727,
           3150, 2118, 4403, 3194, 8475, 1200, 2575, 1299, 1525, 5931, 2166,
           4613, 4909, 8204, 4772, 1374, 8888, 8082, 4862, 1595, 8942, 1899,
           3463, 2022, 7893, 3248, 6486, 2281, 1729, 8620, 1190, 2486, 2158,
           3355, 5353, 2994, 4559, 8521,  973, 7168, 4677, 7537,  493, 1563,
           4860, 9076, 2153, 1550, 5389, 5579, 1783, 2105, 1578, 6729, 1263,
           2011, 4330, 6252, 1820, 6760, 3015, 2285, 7091, 2598, 7962, 7018,
           6290, 5061,  356, 4285, 8540, 2854, 8375, 4310, 4505, 1979, 3532,
           1444, 4934, 8804, 1416, 7334, 2652, 7057, 5525, 2560, 3085, 7445,
           3396, 9062, 2943, 7690, 8198, 4233, 8265, 7750,  353, 8088, 7193,
           7978, 8928, 6567, 6685, 4378, 5363, 2354, 2714,  718, 2559, 5000,
           2664, 6040, 4068, 3570, 9043, 8090, 2483, 3762, 3717, 4112, 1407,
           6740, 6892, 5175,  662, 8452, 7304, 3207, 8505, 6175, 5561, 5633,
           8415, 3660, 3770,  220, 6994, 4253, 1112, 3723, 6725,  746, 8592,
           3496, 5502, 4241, 6933, 4388, 7021, 3097, 3836, 4116, 6314, 8322,
           3165, 6723, 3817, 1534, 1360, 7053, 6944, 4671, 5877, 2673, 3146,
           2343,  745, 1950, 4382, 1682, 7240, 6375, 7941, 5293, 3736, 7450,
           2617, 6127, 4371, 1026, 8113, 6242, 1089, 2243, 2841, 7136, 3477,
           2763, 6890, 4734, 7823, 2870, 5337, 4879, 1467, 3942, 8343, 8052,
           1566, 6461, 5741, 6299, 6501], dtype=int64)



### 3) Finding out the Important Features  from our final model:


```python
res.params.sort_values(ascending=False)
```




    Do Not Call                                             20.546515
    Lead Source_Welingak Website                             5.855007
    Lead Source_Reference                                    3.295021
    What is your current occupation_Working Professional     2.605206
    Last Activity_Other_Activity                             2.098283
    Last Activity_SMS Sent                                   1.100830
    const                                                    1.100730
    Total Time Spent on Website                              1.100024
    Lead Source_Olark Chat                                   1.070087
    Last Activity_Email Opened                               0.665729
    Last Activity_Email Link Clicked                         0.446511
    Last Activity_Unreachable                                0.323210
    Last Notable Activity_Unsubscribed                       0.201656
    Specialization_Hospitality Management                   -0.437790
    City_Tier II Cities                                     -0.580546
    Last Activity_Olark Chat Conversation                   -0.624364
    Last Notable Activity_SMS Sent                          -0.839956
    Last Notable Activity_Email Bounced                     -0.888441
    Lead Origin_Landing Page Submission                     -1.177790
    Specialization_Others                                   -1.197787
    Last Notable Activity_Page Visited on Website           -1.454697
    Do Not Email                                            -1.634424
    Last Notable Activity_Email Opened                      -1.844001
    Last Notable Activity_Olark Chat Conversation           -1.929970
    Last Notable Activity_Email Link Clicked                -2.076474
    Last Notable Activity_Modified                          -2.216027
    Last Notable Activity_View in browser link Clicked     -23.967171
    dtype: float64



## Recommendations:

* The company **should make calls** to the leads coming from the `lead sources "Welingak Websites"`  and `"Reference"` as these are more likely to get converted.
* The company **should make calls** to the leads who are the `"working professionals"` as they are more likely to get converted.
* The company **should make calls** to the leads who spent `"more time on the websites"` as these are more likely to get converted.
* The company **should make calls** to the leads coming from the `lead sources "Olark Chat"` as these are more likely to get converted.
* The company **should make calls** to the leads whose `last activity` was `SMS Sent` as they are more likely to get converted.

* The company **should not make calls** to the leads whose `last activity` was `"Olark Chat Conversation"` as they are not likely to get converted.
* The company **should not make calls** to the leads whose `lead origin` is `"Landing Page Submission"` as they are not likely to get converted.
* The company **should not make calls** to the leads whose `Specialization` was `"Others"` as they are not likely to get converted.
* The company **should not make calls** to the leads who chose the option of `"Do not Email" as "yes"` as they are not likely to get converted.






```python

```


```python

```


```python

```


```python

```
